﻿idiac/java/readme.txt requirements to build and execute idiac.jar java version of idiac
Download and instaill Java http://www.oracle.com/technetwork/java/javase/downloads/
1.  Install java SDK 8+ if you want to compile java source code and create executable jar files
    a.  Note SDK includes SE runtime which is all that is required to execute a jar file.
    b.  Click on SDK Download button and accept terms to start download.
    c.  I installed sdk 8u31 for Windows 10 on 3/23/17)
2.  Alternatively you can just install java SE runtime by clicking on JRE Download if all you want to do is run existing java executable jar files    
    
Example HelloWorldSwing.java
1.  Run HelloWorldSwing_build_jar.bat to compile java to classes and create executable HelloWorldSwing.jar file
2.  Run HelloWorldSwing_run_jar.bat to execute the jar file which pops up small GUI window showing "Hello World"
3.  Alternatively double click on the executable HelloWorldSwing.jar file in directory to execute it or create desktop shortcut to it.

IDIAC Java version 1.04 initial release  as of 2017/07/29 with menu options: file, edit, view, IPL, RUN, STEP, about, and help.
1.  Run idiac_build_jar.bat to compile and link idiac.java source code into executable idiac.jar file (still under construction)
2.  Run idiac_run_jar.bat to execute the jar file which pops up GUI window to run IDIAC source programs.  Note the default
      source program directory is set to c:\idiac\examples\text and can be changed by user 
3.  Alternatively double click on the executable idiac.jar file in directory to execute jar with default user directory.
4.  Once the idiac.jar GUI is running, open idiac example source program such as pi.txt,
5.  Click IPL to load the idiac source program into memory and display first instruction to be executed.
7.  Click on RUN to execute the idiac program and display the last 10 instructions executed and memory dump.
8.  Repeat 4-7 to run other examples and code your own. 
9.  Note the ididac.jar file and edit menus can be used as file text editor to create and modify any text files in addition to progams. 

Eclipse IDE for developing and debugging Java programs
1.  Install Eclipse IDE for developing Java programs: http://www.eclipse.org/downloads/packages/eclipse-ide-java-developers/keplersr1
    (Choose IDE for Windows, Mac, or Linux.  I am using Windows 64 bit version for Windows 10)
2.  Set configuration to use idiac/eclipse/workspace included in the idiac dowload which includes 2 projects: HellowWorldSwirng and idia projects
3.  Open HelloWorldSwing project and run it
4.  Open idiac project and run it
      As you add changes using Eclipse, you can save source via CTRL-S and see any errors listed below
      Once errors are corrected, you can run idiac project via  CTRL-F11
      You can learn about java classes and methods by hovering mouse over a class or method and clicking on doc refs
       See the idiac\development_guide.php for more information about the idiac.java source program.

For questions and answers please join the IDIAC email or Facebook group on www.idiac.org  