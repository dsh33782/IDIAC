/*
 * Copyright 2017 Don Higgins
 * Distributed as open source under General Public License.
 * Maintenance:
 * 2017/06/05 complete file (open, save as, exit) and edit (cut,copy,paste,selectall)
 * 2017/06/07 dsh publish v1.03 with working file, edit, about, and help menu items
 * 2017/07/22 dsh completed RUN and tested PI.TXT running at 67 MIPS on Dell i7 core processor
 * 2017/07/26 dsh don't skip 0 memory values unless above mem_ptr_end, edit view if IPL errors
 * 2017/07/27 dsh add version, save and check if pgm changed at open or exit
 * 2017/07/29 dsh v1.04 last fix MIPS when tot ins = 0 and 
 */ 
 
import java.io.*;
import java.util.Date;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.SwingUtilities;


import java.net.URL;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
public class idiac extends JPanel
                            {

	private static final long serialVersionUID = 1L;
	
	// global data and constants
	static private final String newline = "\n";
	
	// global shared variables
	
	String idiac_version = "V1.04";
	JTextField run_limit_textfield;
	JTextField trace_limit_textfield;
    JTextArea log;
    JTextArea pgm;
    boolean pgm_changed = false;
    JTextArea display;
    String ipl_code;      // text from pgm textarea for parsing during IPL
    int code_ptr = 0;    // ipl_code text index
    JFileChooser fc;
    File file;
    BufferedWriter bw;
    String cur_file_dir = System.getProperty("user.home");
    
    // IPL, RUN, STEP shared variables
    
    boolean ipl_ok = false;
    int tot_errors = 0;
    int tot_ins = 0;
    int run_limit_default =10000000;  // 10 million instructions takes less than 1 second on Dell Intel i7 3.1 GHZ processor
    int run_limit_max = run_limit_default;
    int run_limit = run_limit_max;  
    long   cpu_reg    = 0;
    char   cpu_cc    = '=';
    int ins_opcode = 0;
    int ins_addr = 0;
    int cpu_loc = 0;
    int mem_max = 100; // note if changed, format for instructions will change from op*100+addr
    long[] cpu_mem = new long[mem_max];          // 64 bit integer memory array
    int mem_ptr_end = 0; // end of IPL program code and literals
    String[] label_mem = new String[mem_max];   // string labels for instructions and data in memory from ALC  
    
    int trace_next      = 0;
    int trace_limit_default = 10;
    int trace_limit     = trace_limit_default;
    int trace_max        = 101;
    int[] trace_ins_id    = new int[trace_max];
    int[] trace_ins_loc   = new int[trace_max];
    long[] trace_ins_mem   =  new long[trace_max];
    long[] trace_addr_mem  =  new long[trace_max];
    long[] trace_reg       =  new long[trace_max];
    char[] trace_cc        =  new char[trace_max];
    
    String[] op_mnemonic = {"?","L","ST","A","S","M","D","C","BP","BZ","B"}; // map mnemonics L-B to 1-10 index values for operaction codes
    int code_op_max = 10;
    int code_op_numeric;
      

    
    public idiac(String[] args) {
        super(new BorderLayout());
              
        // textfields for run limit and trace limit
        JTextField run_limit_textfield = new JTextField(6);
        run_limit_textfield.setText("" + run_limit);
        run_limit_textfield.setToolTipText("Set RUN instruction limit");
        JTextField trace_limit_textfield = new JTextField(3);
        trace_limit_textfield.setText("" + trace_limit);
        trace_limit_textfield.setToolTipText("Set RUN instruction trace limit");
        Font mono = new Font("monospaced", Font.PLAIN, 12);
        // log status of all commands in scrolling textarea
        log = new JTextArea(4,40);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
        log.setFont(mono);
        log.append("Log of all IDIAC GUI commands for version " + idiac_version  +  newline);
        JScrollPane logScrollPane = new JScrollPane(log);
       
        //show IDIAC editable source program in scrolling textarea
        
        class PgmDocumentListener implements DocumentListener {
            public void insertUpdate(DocumentEvent e){
              pgm_changed = true;
            }
            public void removeUpdate(DocumentEvent e){
              pgm_changed = true;
            }
            public void changedUpdate(DocumentEvent e){
              pgm_changed = true;
            }
          }
        
        pgm = new JTextArea(20,40);
        pgm.setMargin(new Insets(5,5,5,5));
        pgm.setEditable(true);
        pgm.setFont(mono);
        pgm.append("IDIAC Enter source program to IPL from open file, copy/paste, or text entry" + newline);
        pgm.getDocument().addDocumentListener(new PgmDocumentListener());          
        JScrollPane pgmScrollPane = new JScrollPane(pgm);    
                
        // display trace and memory dump in scrolling textarea
        
        display = new JTextArea(4,40);
        display.setMargin(new Insets(5,5,5,5));
        display.setEditable(false);
        display.setFont(mono);
        display.append("IDIAC Instruction Trace and Memory Dump folling RUN or STEP after IPL" + newline);
        JScrollPane  displayScrollPane = new JScrollPane(display);   
        
        // show trace and dump within mainPanel
        
        JPanel mainPanel = new JPanel();
        
        // set default file directory from first parm else use java system user.home
        
        if (args.length > 0){
        	cur_file_dir = args[0];
            file = new File(cur_file_dir);
            if (!file.isDirectory()){
               log.append("invalid user parm directory = " + cur_file_dir + newline);
            	cur_file_dir = System.getProperty("user.home");
             }
        }
        file = new File(cur_file_dir);
        log.append("Program directory = " + file.getAbsolutePath() +newline);
        
        // init file chooser using cur_file_dir
        
        fc = new JFileChooser(cur_file_dir);
        fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

        
        // handler for menu actions
        
        class MenuActionListener implements ActionListener {
        	  public void actionPerformed(ActionEvent e) {
        	    log.append("Action: " + e.getActionCommand() + newline);
        	    try {
    // file menu
        	    if (e.getActionCommand() == "Open") {
                  if (pgm_changed){
                	 log.append("program changed - select Save, Save As, or Ignore Changes" + newline);
                  } else {
        	        int returnVal = fc.showOpenDialog(idiac.this);

        	        if (returnVal == JFileChooser.APPROVE_OPTION) {
        	           file = fc.getSelectedFile();
        	           try {
        	              FileReader reader = new FileReader(file.getAbsolutePath());
        	              BufferedReader br = new BufferedReader(reader);
                          pgm.read( br, null );
                          log.append("IDIAC source text file " + file.getAbsolutePath() + " loaded  length=" +pgm.getText().length() + newline);
                          br.close();
                          pgm.getDocument().addDocumentListener(new PgmDocumentListener()); // required to restart pgm change listener after open dialog
                          pgm_changed = false;
        	            }
        	            catch(Exception e_open){
        	            	log.append("Open file failed for: " + file.getAbsolutePath() + file.getName() + "." + newline); 
        	            }
           	    	   edit_view();
        	        } else {
        	            log.append("Open file cancelled" + newline);
        	        }
                  }
        	    } else if (e.getActionCommand() == "Save"){
        	    	if (!file.isFile()){
        	    		log.append("save ignored" + newline);
        	    		return;
        	    	}
    	            log.append("Saving Text File: " + file.getAbsolutePath() + file.getName() + "." + newline);
        	    	edit_view();
    	            try {
    	               bw = new BufferedWriter(new FileWriter(file));
    	               pgm.write(bw);
    	               pgm_changed = false;
    	            } catch (IOException ex) {
        	            log.append("Save failed for: " + file.getAbsolutePath() + file.getName() + "." + newline);
    	            }
        	    } else if (e.getActionCommand() == "Save As") {
        	    	edit_view();
        	        int returnVal = fc.showSaveDialog(idiac.this);
        	        if (returnVal == JFileChooser.APPROVE_OPTION) {
        	            file = fc.getSelectedFile();
        	            file = fc.getSelectedFile();
        	            cur_file_dir = file.getParent();
        	            if (!file.getName().endsWith(".txt")) {
        	               file = new File(file.getAbsolutePath() + ".txt"); // force .txt suffix        	            	
        	            }
        	            log.append("Saving As Text File: " + file.getAbsolutePath() + file.getName() + "." + newline);
        	            try {
        	               bw = new BufferedWriter(new FileWriter(file));
        	               pgm.write(bw);
        	               pgm_changed = false;
        	            } catch (IOException ex) {
            	            log.append("Save As failed for: " + file.getAbsolutePath() + file.getName() + "." + newline);
        	            }
        	        } else {
        	            log.append("Save  As  cancelled" + newline);
        	        }
        	    } else if (e.getActionCommand() == "Ignore Changes"){
        	    	pgm_changed = false;
                    log.append("program changes ignored" + newline);
        	    	edit_view();
        	    } else if (e.getActionCommand() == "Exit"){
        	    	if (pgm_changed){
        	    		log.append("program changed - select save, save as, or ignore changes" + newline);
        	    	} else {
        	    	   System.exit(0);
        	    	}
        	    	
       // edit menu 	
        	    } else if (e.getActionCommand() == "Cut"){
        	    	pgm.cut();
        	    	 edit_view();
        	    } else if (e.getActionCommand() == "Copy"){        	    	
        	    	pgm.copy();
        	    	   edit_view();
        	    } else if (e.getActionCommand() == "Paste"){
        	    	pgm.paste();
        	    	   edit_view();
        	    } else if (e.getActionCommand() == "Select All"){
        	    	pgm.selectAll();
        	    	   edit_view();
        // View Menu
        	    } else if (e.getActionCommand() == "Edit View"){
       	    	 edit_view();	
        	    } else if (e.getActionCommand() == "Run View"){
       	    	 run_view();	
        // Other Menu commands
        	    } else if (e.getActionCommand() == "IPL"){
        	      run_view();
        		   idiacIPL();
        	    } else if (e.getActionCommand() == "RUN"){
        	    	run_view();
        		   idiacRUN(run_limit);  
        	    } else if (e.getActionCommand() == "STEP"){
        	      run_view();
        		   idiacRUN(1);
        	    } else if (e.getActionCommand() == "About"){
        	    	openWebsite("www.idiac.org/about.php");
        	    } else if (e.getActionCommand() == "Help"){
        	    	openWebsite("www.idiac.org/help.php");     
        	    } else {
        	    	log.append("Action: " + e.getActionCommand() + " not implements yet" + newline);
        	    }  // end of action performed event alternatives
      	        // log.setCaretPosition(log.getDocument().getLength());
        	    }
           	    catch(Exception emenu){
        		 log.append("menu exception within " + e.getActionCommand() + newline + "  error=" +emenu.toString() + newline);
        	    }
        	 }    // end of ActionPerformed

        } // end of MenuActionListener class      
        
        
   // define menu and submenu items for menu bar along with action listerers
        
        JMenu file_menu = new JMenu("File");
            JMenuItem file_menu_open = new JMenuItem("Open");
            file_menu_open.addActionListener(new MenuActionListener()) ;
            file_menu_open.setToolTipText("Open IDIAC program source text file");
            JMenuItem file_menu_save = new JMenuItem("Save");
            file_menu_save.addActionListener(new MenuActionListener());
            file_menu_save.setToolTipText("Save updates to current IDIAC source program text file");
            JMenuItem file_menu_save_as = new JMenuItem("Save As");
            file_menu_save_as.addActionListener(new MenuActionListener());
            file_menu_save_as.setToolTipText("Save current IDIAC source program to selected text file");
            JMenuItem file_menu_ignore = new JMenuItem("Ignore Changes");
            file_menu_ignore.addActionListener(new MenuActionListener());
            file_menu_ignore.setToolTipText("Ignore source program changes to allow open or exit");
            JMenuItem file_menu_exit = new JMenuItem("Exit");
            file_menu_exit.addActionListener(new MenuActionListener());         
            
          JMenu edit_menu = new JMenu("Edit");
             JMenuItem edit_menu_cut = new JMenuItem("Cut");
             edit_menu_cut.addActionListener(new MenuActionListener()) ;
             edit_menu_cut.setToolTipText("Cut selected text from current IDIAC program");
             JMenuItem edit_menu_copy = new JMenuItem("Copy");
             edit_menu_copy.addActionListener(new MenuActionListener());
             edit_menu_copy.setToolTipText("Copy selected text from current IDIAC program to clipboard");
             JMenuItem edit_menu_paste = new JMenuItem("Paste");
             edit_menu_paste.addActionListener(new MenuActionListener());
             edit_menu_paste.setToolTipText("Paste clipboard to selected text in current IDIAC program");
             JMenuItem edit_menu_select = new JMenuItem("Select All");
             edit_menu_select.addActionListener(new MenuActionListener());
             edit_menu_select.setToolTipText("Select all text in current IDIAC program");
             
             JMenu view_menu = new JMenu("View");
             JMenuItem view_menu_edit = new JMenuItem("Edit View");
             view_menu_edit.addActionListener(new MenuActionListener()) ;
             view_menu_edit.setToolTipText("Set Edit source program view");
             JMenuItem view_menu_ipl = new JMenuItem("Run View");
             view_menu_ipl.addActionListener(new MenuActionListener());
             view_menu_ipl.setToolTipText("Set IPL and Run view with instruction trace and memory dump");           
             
          
      JMenuItem ipl_menu = new JMenuItem("IPL");
      ipl_menu.addActionListener(new MenuActionListener());
      ipl_menu.setToolTipText("IPL Initial Program Load into memory");
     ipl_menu.setPreferredSize(new Dimension(30,ipl_menu.getPreferredSize().height));
      JMenuItem run_menu = new JMenuItem("RUN");
      run_menu.addActionListener(new MenuActionListener());
      run_menu.setToolTipText("Run IDIAC program in memory");
      run_menu.setPreferredSize(new Dimension(30,run_menu.getPreferredSize().height));
      JMenuItem step_menu = new JMenuItem("STEP");     
      step_menu.addActionListener(new MenuActionListener());
      step_menu.setToolTipText("Execute next instruction");
      JMenuItem about_menu = new JMenuItem("About");
      about_menu.addActionListener(new MenuActionListener());
      about_menu.setToolTipText("Open About page on www.idiac.org");
      JMenuItem help_menu = new JMenuItem("Help");
      help_menu.addActionListener(new MenuActionListener());
      help_menu.setToolTipText("Open Help page on www.idiac.org");
      
    // add jtextfield listners
      
      class RunLimitActionListener implements ActionListener {
    	  public void actionPerformed(ActionEvent aerun) {
    	    try{
    	      run_limit = Integer.parseInt(run_limit_textfield.getText());
    	    } catch(Exception erun){
    		    log.append("Run Limit invalid  - reset to " + run_limit_default + newline);
    		    run_limit = run_limit_default;
    	    }
       	    if (run_limit < 1)run_limit = run_limit_default;
       	    if (run_limit > run_limit_max)run_limit = run_limit_default;
       	   run_limit_textfield.setText("" + run_limit);
    	    log.append("Run Limit = " + run_limit + " max instructions executed per run unit" + newline);
    	  }
      }
      run_limit_textfield.addActionListener(new RunLimitActionListener());
      class TraceLimitActionListener implements ActionListener {
    	  public void actionPerformed(ActionEvent aetrace) {
      	    try{
      	        trace_limit = Integer.parseInt(trace_limit_textfield.getText());
      	    } catch(Exception etrace){
      		    log.append("Trace Limit invalid - reset to " + trace_limit_default + newline);
      		    trace_limit = 10;
      	    }
    	   if (trace_limit < 1)trace_limit = trace_limit_default;
    	   if (trace_limit >= trace_max)trace_limit = trace_max -1;
    	   trace_limit_textfield.setText("" + trace_limit);
    	    log.append("Trace Limit = " + trace_limit + " last instructions executed" + newline);
    	  }
      }
      trace_limit_textfield.addActionListener(new TraceLimitActionListener());
      
    // create menuBar
      
      JMenuBar menuBar = new JMenuBar();
      
      menuBar.add(file_menu);
        file_menu.add(file_menu_open);
        file_menu.add(file_menu_save);
        file_menu.add(file_menu_save_as);
        file_menu.add(file_menu_ignore);
        file_menu.add(file_menu_exit);
        
      menuBar.add(edit_menu);
        edit_menu.add(edit_menu_cut);
        edit_menu.add(edit_menu_copy);
        edit_menu.add(edit_menu_paste);
        edit_menu.add(edit_menu_select);
        
        menuBar.add(view_menu);
        view_menu.add(view_menu_edit);
        view_menu.add(view_menu_ipl);
        
      menuBar.add(ipl_menu);
      menuBar.add(run_menu);
      menuBar.add(step_menu);
      menuBar.add(about_menu);
      menuBar.add(help_menu);
      menuBar.add(run_limit_textfield);
      menuBar.add(trace_limit_textfield);
      
      JPanel menuPanel = new JPanel(); //use FlowLayout

      menuPanel.add(menuBar);
      
    // Add panels for menu bar, log of commands, pgm source, and display of trace and dump


       add(menuPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.add(logScrollPane);
        mainPanel.add(pgmScrollPane);
        mainPanel.add(displayScrollPane);
        
    }
    public void edit_view(){
    	log.setRows(8);
        pgm.setRows(16);
        display.setRows(4);
       //  log.append("Set Edit View" + newline);
        pgm.requestFocus();
        updateUI();
    }
    public void run_view(){
    	log.setRows(4);
        pgm.setRows(4);
        display.setRows(20);
        // log.append("Set Run View" + newline);
        pgm.requestFocus();
        updateUI();
    }
    public void openWebsite(String urlString) {
        try {
        	Desktop.getDesktop().browse(new URL("http://" + urlString).toURI());
        } catch (Exception e) {
            log.append("openWebsite failed to open " + urlString + "error "  + e.getMessage() +  newline);
        }
    }
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    public boolean next_char(String type_comp,String comp_value){
		boolean test_return = false; 
    	if (code_ptr < ipl_code.length()){
    		char test_char = ipl_code.charAt(code_ptr);
    		char test_value = comp_value.charAt(0);
    		if (type_comp.compareTo("EQ") == 0 & test_char == test_value)test_return = true;
    		if (type_comp.compareTo("LT") == 0 & test_char < test_value)test_return = true;;
    		if (type_comp.compareTo("GT") == 0 & test_char > test_value)test_return = true;
    		if (type_comp.compareTo("NE") == 0 & test_char != test_value)test_return = true;
    	   	if (type_comp.compareTo("LE") == 0 & test_char <= test_value)test_return = true;
    		if (type_comp.compareTo("GE") == 0 & test_char >= test_value)test_return = true;
    		// log.append("next_char '" + test_char + "' at " + code_ptr + " " + type_comp + " '"  + test_value + "' result=" + test_return + newline);
    	} else {
    		 // log.append("next_char not found code_ptr=" + code_ptr + "ipl_code.length()=" + ipl_code.length() + newline);
    	}
    	return test_return;
    }
    public void update_trace_entry(){
    	// update trace for next instruction to be executed (called by IPL and RUN with cpu_loc, tot_ins, and trace_next)
        ins_opcode = (int)(cpu_mem[cpu_loc]/mem_max);
        ins_addr      = (int) (cpu_mem[cpu_loc]-ins_opcode * mem_max);
        trace_ins_id[trace_next]          =(tot_ins+1);
        // log.append("update trace_next=" + trace_next + "  trace_id=" + trace_ins_id[trace_next] + newline);
        trace_ins_loc[trace_next]        =cpu_loc;
        trace_ins_mem[trace_next]    =cpu_mem[cpu_loc];
        trace_addr_mem[trace_next] = cpu_mem[ins_addr];
        trace_reg[trace_next]             = cpu_reg;
        trace_cc[trace_next]               = cpu_cc;
    }
    public String left_justify(String text,int padded_len){
    	/*
    	 * return text left justified in field
    	 * if field larger than text
    	 */
    	if (text == null){
    		return "";
    	}
    	int pad_len = padded_len - text.length();
    	if (pad_len > 0){
    		String spaces = "";
    		while (pad_len > 0){
    			spaces = (spaces + ' ');
    			pad_len -= 1;
    		}
    		return (" " + text + spaces);
    	} else {
    		return (" " + text);
    	}
    }

    public String right_justify(String text,int padded_len){
    	/*
    	 * return text right justified in field
    	 * if field larger than text
    	 */
    	int pad_len = padded_len - text.length();
    	if (pad_len > 0){
    		String spaces = "";
    		while (pad_len > 0){
    			spaces = (spaces + ' ');
    			pad_len -= 1;
    		}
    		return ("" +spaces + text);
    	} else {
    		return text;
    	}
    }

    public void display_trace_and_memory(){
    	display.setText(null);
    	display.append(right_justify("Trace ID",8)
                + right_justify("Loc",4)
                + right_justify("Word",5)
                + left_justify("Label",8)
                + left_justify("Op",3)
                + left_justify("Label",8)
                + right_justify("Ref",4)
                + right_justify("Register",15)
                + left_justify("COND",5)
                + newline);
        boolean trace_done = false;
        int trace_cur = trace_next + 1;
        if (trace_cur >= trace_limit)trace_cur = 0;
        while(!trace_done){
        	// log.append("display trace trace_cur=" + trace_cur + " trace_ins_id=" + trace_ins_id[trace_cur] + newline);
           if (trace_ins_id[trace_cur] > 0){ 
              ins_opcode = (int)(trace_ins_mem[trace_cur]/mem_max);
              ins_addr      = (int)(trace_ins_mem[trace_cur]-ins_opcode * mem_max);
              if (ins_opcode > code_op_max)ins_opcode = 0;
             String  ins_op     = op_mnemonic[ins_opcode];
              display.append(right_justify("" + trace_ins_id[trace_cur],8)
		                             + right_justify("" + trace_ins_loc[trace_cur],4)
                                     + right_justify("" + trace_ins_mem[trace_cur],5)
                                     + left_justify("" + label_mem[trace_ins_loc[trace_cur]],8)
                                     + left_justify("" + ins_op,3)
                                     + left_justify("" + label_mem[ins_addr],8)
                                     + right_justify("" + ins_addr,4)
                                     + " " + right_justify("" + trace_reg[trace_cur],15)
                                     + left_justify("" + trace_cc[trace_cur],5) + newline);
              if (trace_cur == trace_next)trace_done = true;
           }
           trace_cur += 1;
           if (trace_cur >= trace_limit)trace_cur = 0;            
        }
        display.append("Memory Dump" + newline);
        display.append(right_justify("Loc",4)
                + left_justify("Label",8)
                + right_justify("Word ",5)
                + newline);
        ins_addr = 0;
        while(ins_addr < mem_max){
          if (ins_addr <= mem_ptr_end | cpu_mem[ins_addr] != 0){
              display.append(right_justify("" + ins_addr,4)
                                     + left_justify("" + label_mem[ins_addr],8)
                                     +right_justify("" + cpu_mem[ins_addr],5)
                                     + newline);
          }
          ins_addr += 1;
        }
        display.setCaretPosition(0);
    }
    public void idiacIPL(){
    	   // reset to support multiple IPL's
    	   cpu_reg = 0;
    	   cpu_cc   = '=';
    	    int i = 0;
    	    while (i < mem_max){
    	    	cpu_mem[i]=0;
    	    	label_mem[i]="";  // init mem labels to empty string vs null
    	    	i +=1;
    	    }

          
          // load multiple mlc | alc instructions into cpu_mem       
         
          ipl_ok = false;
          tot_errors            = 0;
          tot_ins = 0;
          int tot_label_def      = 0;
          int label_def_ptr      = 0;
          String[] code_label_def     = new String[mem_max];  // instruction label
          Integer[] code_label_def_loc = new Integer[mem_max];   // iabel address
          int tot_label_ref      = 0;  
          int label_ref_ptr      = 0;    
          String[] code_label_ref     = new String[mem_max];  // label ref
          Integer[] code_label_ref_loc = new Integer[mem_max];   // label ref address
          int tot_labels   = 0;
          int tot_opcodes  = 0;
          int tot_literals = 0;
          int mem_ptr = 0;        // cpu_mem index
          int code_start;        // start of label
          boolean label_found = false;
          String code_value = "";
          String code_op_mnemonic = "";
          ipl_code = pgm.getText();
         if (ipl_code.length() > 11){
        	 if (ipl_code.substring(0,11).equals("IDIAC Enter"))ipl_code = "";
         }
         if (ipl_code.length() < 3){
        	 tot_errors += 1;
        	 ipl_ok = false;
        	 log.append("IPL error - no source code found (open file, copy/paste, or text edit" + newline);
        	 return;
         }

         code_ptr = 0;

          while (mem_ptr < mem_max & code_ptr < ipl_code.length()){

        	//  log.append("skip delimiters at mem_ptr = " + mem_ptr + " code_ptr = " + code_ptr + newline) ;
             
        	  while (next_char("LT"," ") | next_char("EQ",";")){
        		  code_ptr += 1; 
              }

            // skip entire lines starting with *
            
              while (next_char("EQ","*")){
                 while (next_char("GE"," ") & next_char("NE",";")){ // stop at end or cr/lf or ;
                	 code_ptr += 1; 
                 }
                 while (next_char("LT"," ") | next_char("EQ",";")){ // stop at end or first char in next line after cr/lr or ;
                	 code_ptr += 1; 
                 }               
              }

              // get_label() - skip delimiters, if label at start of field, set mem_label & mem_label_addr
  
                code_start = code_ptr;                  
                if (next_char("GT","9") & next_char("NE",";")){  // build label def
                   if (code_ptr == code_start){                      
                	   
                      // set_label() - add mem_label & mem_label_addr
                      
                      code_label_def[tot_label_def] = String.valueOf(ipl_code.charAt(code_ptr));
                      code_label_def_loc[tot_label_def] = mem_ptr; // cpu_mem address of label
                      code_ptr += 1;
                      while (next_char("GT"," ") & next_char("NE",";")){
                         code_label_def[tot_label_def] = code_label_def[tot_label_def].concat(String.valueOf(ipl_code.charAt(code_ptr)));
                         code_ptr += 1;                         
                      }
                      label_mem[mem_ptr] = code_label_def[tot_label_def];
                      // log.append("set label " + code_label_def[tot_label_def] + " at " + mem_ptr + newline);
                      tot_label_def += 1;
                      tot_labels    += 1;
                   }               
                }
         
              // get_op() - skip spaces, get op mnemonic, & set cpu_mem opcode

                  // log.append("get_op at " + code_ptr +newline); // debug  
                  cpu_mem[mem_ptr] = 0;
                  while (next_char("EQ"," ")){ // skip spaces
                      code_ptr += 1;
                  }
                  if  (next_char("GT","9") & next_char("NE",";")){ // build op mnemonic
                      code_op_mnemonic = Character.toString(ipl_code.charAt(code_ptr)).toUpperCase();
                      //  log.append("get_op " + code_op_mnemonic + " at " + code_ptr +newline); // debug
                      code_ptr += 1;
                      while (next_char("GT"," ") & next_char("NE",";")){
                         code_op_mnemonic =  code_op_mnemonic.concat(Character.toString(ipl_code.charAt(code_ptr)).toUpperCase());
                         code_ptr += 1;
                      }  
                      code_op_numeric = 1;
                      boolean op_found = false;
                      while (!op_found & code_op_numeric <= code_op_max){
                    	  if (op_mnemonic[code_op_numeric].compareTo(code_op_mnemonic) == 0){
                          	  //  log.append("compare op = " + code_op_mnemonic + " with op_mnemonic " + op_mnemonic[code_op_numeric] + newline);
                    	       op_found = true;
                    	  } else {
                          	   code_op_numeric++;
                    	  }
                      }
                      if (op_found){
                         cpu_mem[mem_ptr] = code_op_numeric * mem_max; // set opcode with zeros for address
                         // log.append("set opcode " + code_op_numeric + " at " + mem_ptr + newline);
                         tot_opcodes += 1;
                      } else {
                    	tot_errors +=1;
                         log.append("IPL error - undefined opcode " + code_op_mnemonic + " at " + mem_ptr+ newline);
                      }
                  }
              
              // get_label_ref() - skip spaces, get label ref, add code_label_ref
                  
                  while (next_char("EQ"," ")){ // skip spaces
                	  code_ptr += 1; 
                  }
                  if  (next_char("NE",";") & (next_char("GT","9") | next_char("EQ","#")) ){ // build label  or literal ref
                	  code_label_ref[tot_label_ref] = String.valueOf(ipl_code.charAt(code_ptr));
                      code_label_ref_loc[tot_label_ref] = mem_ptr; 
                      code_ptr += 1; 
                      while (next_char("GT"," ") & next_char("NE",";")){ // build label ref
                          code_label_ref[tot_label_ref] = code_label_ref[tot_label_ref].concat(String.valueOf(ipl_code.charAt(code_ptr)));
                          code_ptr += 1;
                      }
                      // log.append("set label ref " + code_label_ref[tot_label_ref] + " at " + mem_ptr + newline);
                      tot_label_ref += 1;

                  // skip comments after ref label

                  while (next_char("GE"," ") & next_char("NE",";")){ // stop at end | cr/lf | ";"
                	  code_ptr += 1; 
                   }
              }

 // get_value() - skip spaces, get signed decimal value f| mem|y w|d & add to cpu_mem
             
                  while (next_char("EQ"," ")){  // skip spaces        
                	  code_ptr += 1; 
                  }
                  while (next_char("GE","0") & next_char("LE","9") | next_char("EQ","-") | next_char("EQ","+")){
                      code_value = String.valueOf(ipl_code.charAt(code_ptr)); 
                      code_ptr += 1; 
                      while (next_char("GE","0") & next_char("LE","9")){                      
                         code_value = code_value.concat(String.valueOf(ipl_code.charAt(code_ptr)));
                         code_ptr += 1; 
                      }
                      try {
                        cpu_mem[mem_ptr] += Long.parseLong(code_value); // add value to cpu_mem opcode                  
                      }
                      catch (Exception e){
                    	  tot_errors +=1;
                    	  log.append("invalid value at loc " + mem_ptr +newline);
                      }
                        // log.append("set value cpu_mem[" + mem_ptr + "]=" + code_value + newline); // debug              
                  }
           
   // skip comments
              
               while (next_char("GE"," ") & next_char("NE",";")){ // skip comments and stop at end | cr/lf | ";"
            	   code_ptr += 1; 
                }
               
     // next memory location to parse and load      
              mem_ptr += 1;         
   
          } // end parsing ipl_code for mem|y load of instructions & data
           
      // allocate literals

           label_ref_ptr = 0;
           while (label_ref_ptr < tot_label_ref){
              label_def_ptr = 0;
              label_found = false;
              while (label_def_ptr < tot_label_def){
                 if (code_label_ref[label_ref_ptr] == code_label_def[label_def_ptr]){
                    label_found = true; // label already allocated so ignore                  
                    label_def_ptr = tot_label_def; // force end of def search
                 }
                 label_def_ptr += 1; // search for next ref label def        
              }
              if (!label_found & code_label_ref[label_ref_ptr].charAt(0) == '#'){
            	 // log.append("add literal " + code_label_ref[label_ref_ptr] + " at " + mem_ptr);
            	 try {
                   cpu_mem[mem_ptr] = Long.parseLong(code_label_ref[label_ref_ptr].substring(1)); // add constant lit to end of program in mem|y
            	 }
            	 catch (Exception e){
            		 tot_errors +=1;
            		 log.append("invalid value at loc " + mem_ptr + newline);
            	 }
                   label_mem[mem_ptr] = code_label_ref[label_ref_ptr];
                //  log.append("set literal " + code_label_ref[label_ref_ptr] + " at " + mem_ptr + newline);
                 code_label_def[tot_label_def] = code_label_ref[label_ref_ptr]; 
                 code_label_def_loc[tot_label_def] = mem_ptr; 
                 mem_ptr += 1; 
                 tot_label_def += 1; // add literal definition
                 tot_literals  += 1; // count literals           
              }
              label_ref_ptr += 1;
           }  // end processing label references
           
           // add END label to refenece first location past literals

           code_label_def[tot_label_def] = "END"; 
           code_label_def_loc[tot_label_def] = mem_ptr;
           mem_ptr_end = mem_ptr;
           label_mem[mem_ptr_end] = "END"; 
           // log.append("add END literal at " + mem_ptr + newline);
           tot_label_def += 1; // add literal definition
           
           // lookup label refs & add label loc to cpu_mem opcode
           
           label_ref_ptr = 0;
           while (label_ref_ptr < tot_label_ref){
              label_def_ptr = 0;
              label_found = false;
              while (label_def_ptr < tot_label_def){
                 if (code_label_ref[label_ref_ptr].compareTo(code_label_def[label_def_ptr]) == 0){
                    label_found = true;
                    cpu_mem[code_label_ref_loc[label_ref_ptr]] += code_label_def_loc[label_def_ptr];                  
                    // log.append("set label ref " + code_label_ref[label_ref_ptr] + " at " + code_label_ref_loc[label_ref_ptr] + " to " + code_label_def_loc[label_def_ptr] + newline);
                    label_def_ptr = tot_label_def; // f|ce end of def search
                 }
                 label_def_ptr += 1;             
              }
              if (!label_found){
            	  tot_errors +=1;  
                 log.append("IPL error undefined label " + code_label_ref[label_ref_ptr] + "  at " + code_label_ref_loc[label_ref_ptr] + newline);
              }
              label_ref_ptr += 1;
              
           }  // end processing label references
           
           log.append("IPL errors=" + tot_errors + " words=" + mem_ptr + " opcodes=" + tot_opcodes + " liternals=" + tot_literals + " labels=" + tot_labels + newline);
           if (tot_errors == 0){
        	   ipl_ok = true;
        	   cpu_loc = 0;
        	   trace_next = 0;
        	   while (trace_next < trace_limit){
        		   trace_ins_id[trace_next] = 0;
        		   trace_next += 1;
        	   }
        	   trace_next = 0;
        	   update_trace_entry();
               display_trace_and_memory();
           } else {
        	   display.setText("IPL errors - correct source program errors and IPL again" + newline);
        	   edit_view();
           }
    }

public static String getCurrentTimeStamp() {
    SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
    Date now = new Date();
    String strDate = sdfDate.format(now);
    return strDate;
}
    public void idiacRUN(int exec_limit){
      if (!ipl_ok){
     	 log.append("RUN/STEP ignored due to IPL error" + newline);
     	 return;
      }
      int    run_start_ins     = tot_ins;
      Long run_start_millis =System.currentTimeMillis();      
      log.append("Run started " + getCurrentTimeStamp() +newline);    
      boolean exec             = true;
      boolean  step             = true; 
      boolean repeat_step = true;
     //  if (exec_limit == 1) repeat_step = false;

// execute instructions for step or run   
   
   exec    = true; // save trace info and then execute step if step or run, repeat while (exec, step, and repeat step)
  int  run_ins = 0;    // count instructions in run unit up to run_limit and add to tot_ins for all run units since IPL
   while (exec){
     update_trace_entry();  // record trace of instruction at trace_next for each instruction executed plus the next pending instruction   
         
     if (step){ // execute  instruction at cpu_loc until run_ins == exec_limit
         // log.append("Start ins switch for loc=" + cpu_loc + " op=" + ins_opcode + newline);
    	 switch (ins_opcode) {
         case 1: // L - load 
           cpu_reg = cpu_mem[ins_addr];          
           cpu_loc += 1;          
         break;
         case 2: // ST - store
           cpu_mem[ins_addr] = cpu_reg;
           cpu_loc += 1;
         break;        
         case 3: // A - add 
           cpu_reg = cpu_reg + cpu_mem[ins_addr];          
           if (cpu_reg > 0){
              cpu_cc = '>';
           } else if (cpu_reg < 0){
              cpu_cc = '<';
           } else {
              cpu_cc = '=';
           }  
           cpu_loc += 1;          
         break;
         case 4: // S - subtract 
           cpu_reg =  cpu_reg - cpu_mem[ins_addr];
           if (cpu_reg > 0){
              cpu_cc = '>';
           } else if (cpu_reg < 0){
              cpu_cc = '<';
           } else {
              cpu_cc = '=';
           } 
           cpu_loc += 1;
         break;
         case 5: // M - multiply 
           cpu_reg = cpu_reg * cpu_mem[ins_addr];
           if (cpu_reg > 0){
              cpu_cc = '>';
           } else if (cpu_reg < 0){
              cpu_cc = '<';
           } else {
              cpu_cc = '=';
           } 
           cpu_loc += 1;
         break;
         case 6: // D - divide          
           if (cpu_mem[ins_addr] != 0){
              cpu_reg = cpu_reg / cpu_mem[ins_addr];
              
              if (cpu_reg > 0){
                 cpu_cc = '>';
              } else if (cpu_reg < 0){
                 cpu_cc = '<';
              } else {
                cpu_cc = '=';
              }          
              cpu_loc += 1;
           } else {
              tot_errors +=1;
              log.append("RUN error divide by zero error at " + cpu_loc + newline);
           }          
         break;
         case 7: // C - compare 
           if (cpu_reg > cpu_mem[ins_addr]){
              cpu_cc =  '>';
           } else if (cpu_reg < cpu_mem[ins_addr]){
              cpu_cc = '<';
           } else {
              cpu_cc = '=';
           }
           cpu_loc += 1;          
         break;
         case 8: // BP - branch positive to addr
           if (cpu_cc == '>'){
              if (ins_addr == cpu_loc){
            	  tot_errors +=1;
                 log.append("RUN error BP to self loop stopped at " + cpu_loc + newline);
              }
              cpu_loc = ins_addr;
           } else {          
              cpu_loc += 1;
           }         
         break;        
         case 9: // BZ - branch zero to addradd 
           if (cpu_cc == '='){
              if (ins_addr == cpu_loc){
            	  tot_errors +=1;
                 log.append("RUN error BZ to self loop stopped at " + cpu_loc + newline);
              }
              cpu_loc = ins_addr;
           } else {          
              cpu_loc += 1;             
           }            
         break;
         case 10: // B - branch to addr
           if (ins_addr == cpu_loc){
        	   tot_errors +=1;
              log.append("RUN error B to self loop stopped at " + cpu_loc + newline);
           }  
           cpu_loc =  ins_addr;
          break;
          default:
        	  tot_errors +=1;
              log.append("RUN error Invalid opcode " + ins_opcode + " at " + cpu_loc + newline);
       }
       if (cpu_loc >= mem_max){
        	 tot_errors +=1;
            log.append("RUN error - end of memory" + newline);
       }
      if (tot_errors == 0){
         run_ins += 1;
         tot_ins += 1;
      } else {
         step = false;
      }
     } // end if step
     
     if (!repeat_step){
        exec = false;
     } else {
        trace_next += 1;
        if (trace_next >= trace_limit)trace_next = 0;
        if (tot_errors > 0 | run_ins >= exec_limit){
           repeat_step = false;
           step        = false;
        }
     } 
   }  // end while exec
   
   int    run_unit_ins        = tot_ins - run_start_ins;
   Long run_end_millis =System.currentTimeMillis();  
   Long run_millis         =       run_end_millis - run_start_millis;
   double run_seconds    = (float)(run_millis)/1000.;
   double run_mips            = 0;   
   if (run_seconds > 0){
      run_mips = (float)(run_unit_ins)/(1000000.*run_seconds);
  }
  DecimalFormat dec = new DecimalFormat("###.###");
   log.append("Run ended   " + getCurrentTimeStamp() + newline);
   log.append("Run unit ins. = " + run_unit_ins + "  seconds = " + dec.format(run_seconds) + "  MIPS =" + dec.format(run_mips) + newline );
   display_trace_and_memory();
  }
    

    
    private static void createAndShowGUI(String[] args) {
        //Create and set up the window.
        JFrame frame = new JFrame("IDIAC");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.add(new idiac(args));
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI(args);
            }
        });
    }
    
    public static int okcancel(String theMessage) {
        int result = JOptionPane.showConfirmDialog((Component) null, theMessage,
            "alert", JOptionPane.OK_CANCEL_OPTION);
        return result;
      }
}