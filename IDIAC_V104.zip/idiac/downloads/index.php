<?php
// IDIAC Machine Language Emulator Download page
// copyright 2017 Don Higgins under open source general public license
// 2017/05/04 dsh initial coding copied from examples/index.php

//**********************************************************************
  require '../php/functions.php';
  
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC Machine Language Emulator Downloads Page</title>
</head>

<?php page_header("IDIAC Open Source Downloads")

?>

<table align="left" width="800">
<tr><td>
	<ul>
		<li><strong>IDIAC Open Source Downloads&nbsp;&nbsp;&nbsp; 
		</strong> 
		<ul>
			<li><strong>2017/07/30
			IDIAC_V1.04.zip with complete J2SE Java version of IDIAC </strong>
			<ul>
				<li><strong>File menu with open, save, and save as to access 
				idiac source text files</strong></li>
				<li><strong>Example to calculate Pi to 3.14159 using series 
				after 10 million instructions</strong></li>
			</ul>
			</li>
			<li><strong>2017/06/07 <a href="IDIAC_V103.zip">IDIAC_V1.03.zip</a> with updated idiac java version </strong>
			<ul>
				<li><strong>idiac.java source (about 220 lines) updated with 
				support for menu actions: </strong>
				<ul>
					<li><strong>File (open, save as) - read and write idiac 
					source text files</strong></li>
					<li><strong>Edit (cut, copy, paste, select all) - update 
					current idiac source panel</strong></li>
					<li><strong>About, and Help - opens selected webpage on 
					www.idiac.org</strong></li>
				</ul>
				</li>
				<li>The only remaining actions to add are IPL loader, Run, and 
				Step</li>
			</ul>
			</li>
			<li><strong>2017/05/29 </strong><a href="IDIAC_V102.zip"><strong>
			IDIAC_V1.02.zip</strong></a><strong> First java release with 
			executable GUI menu only version </strong><ul>
				<li><strong>Add pop-up descriptions for textarea, textboxes, and buttons 
				for mouse</strong></li>
				<li><strong>Add example to calculate perfect numbers beyond 6 = 28, 496, 
				8128, and 33550336</strong></li>
				<li><strong>Add java directory with java version of IDIAC</strong><ul>
					<li><strong>readme.txt - text document describing how to build 
					executable idiac.jar version using BAT commands or open 
					source Eclipse IDE with help </strong></li>
					<li><strong>HelloWorldSwing.java - Hello World java demo from Oracle</strong></li>
					<li><strong>HelloWorldSwing_build_jar.bat - build executable 
					HelloWorldSwing.jar</strong></li>
					<li><strong>HelloWorldSwing_run_jar - execute HelloWorldSwing.jar</strong></li>
					<li><strong>idiac.java - java idiac open source code (currently 63 
					lines for GUI menu only)</strong></li>
					<li><strong>idiac_build_jar.bat - compile and link idiac.java into 
					executable idiac.jar idiac_run_jar.bat - execute idiac.jar 
					(alternatively double click on it)</strong></li>
					<li><strong>eclipse/workspace directory with 2 projects for Eclipse 
					IDE to develop java</strong><ul>
						<li><strong>HelloWorldSwing project if you want to change it</strong></li>
						<li><strong>idiac project if you want to help develop it</strong></li>
					</ul>
					</li>
				</ul>
				</li>
			</ul>
			</li>
			<li><strong>2017/05/09 </strong><a href="IDIAC_V101.zip"><strong>
			IDIAC_V1.01.zip</strong></a><strong> Initial Release with examples</strong></li>
		</ul>
		</li>
	</ul>
   </td>
</tr>
</table>

<?php

  page_footer();
  
// end help.php
		

