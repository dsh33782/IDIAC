<?php
// IDIAC Machine Language Emulator Help page
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding
// 2017/04/16 dsh use rel ref from root

//**********************************************************************
  require 'php/functions.php';
  
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC Machine Language Emulator Help Page</title>
</head>

<?php page_header("IDIAC Help Page")

?>


<tr><td>
	<ul>
		<li><strong>Join the </strong> <a href="https://www.facebook.com/groups/IDIAC/">
		<strong>IDIAC 
		Facebook Discussion Group</strong></a><strong> or </strong>
		<a href="https://groups.yahoo.com/neo/groups/IDIAC/info"><strong>Yahoo 
		Email Group</strong></a><strong> for support</strong><ul>
			<li><strong>Post questions about IDIAC and shared program computers</strong></li>
			<li><strong>Post example IDIAC assembler programs you would like to 
			share</strong></li>
		</ul>
		</li>
		<li><strong>Frequently Asked Questions and Answers</strong><ul>
			<li><strong>How do I code and test an IDIAC source assembler test 
			program?</strong><ul>
				<li><strong>Code the program using any
				<a href="http://www.asciitable.com/">ASCII</a> text editor you 
				like and save it.</strong></li>
				<li><strong>Select the program text and copy it to clipboard 
				(usually CNTL-C).</strong></li>
				<li><strong>Open </strong><a href="http://www.idiac.org">
				<strong>www.idiac.org</strong></a><strong> and select all the 
				text in text area (initially the text area contains default sample 
				program such as powers of 2 to 2*63).&nbsp; For the Java version 
				you can copy and paste source code to the pgm text area, or you 
				can read the source program directly from text file on the same 
				platform.&nbsp; You can navigate to the directory, or you can 
				add parameter to idiac.jar execution line to set default 
				directory.</strong></li>
				<li><strong>Paste your source program in the text area (usually 
				CTRL-V).</strong></li>
				<li><strong>Click IPL button to load program into IDIAC memory.&nbsp; 
				First error found will be displayed or message saying IPL 
				loading complete will appear.&nbsp; The java version will list 
				all errors in the log text area and show total.</strong></li>
				<li><strong>Once program loads without error, click on RUN to 
				execute the program.</strong></li>
				<li><strong>To debug execution errors, you can reload program 
				via IPL 
				and then step or run for a limited number of instructions to see 
				which is happening via the trace table display.</strong></li>
			</ul>
			</li>
			<li><strong>Why does the trace register value next to an instruction 
			not show the operation result?</strong><ul>
				<li><strong>Each trace line shows the instruction, operand 
				memory, register, and condition code at the beginning of each 
				instruction so you can determine what the inputs to the 
				instruction are.&nbsp; If you execute a step and look at next 
				trace entry, it will show operand memory, register, and/or 
				condition changes as result of previous instruction. </strong>
				</li>
			</ul>
			</li>
		</ul>
		<ul>
			<li><strong>References:</strong><ul>
				<li>
				<a href="https://en.wikipedia.org/wiki/Stored-program_computer">About stored program computers</a></li>
				<li><a href="about.php">About IDIAC</a> - A simple stored 
				program computer you can learn to program</li>
				<li><a href="https://www.w3schools.com/tags/">HTML</a> - 
				Hypertext meta language for all web pages</li>
				<li><a href="http://php.net/manual/en/langref.php">PHP</a> - an 
				open source interpretive language which generate HTML web pages<ul>
					<li><a href="downloads">Download open source PHP version of 
					IDIAC for the web</a></li>
					<li>
					<a href="https://www.microsoft.com/en-us/download/details.aspx?id=36179">
					Download Microsoft Expressing Web for editing and publishing 
					PHP code</a></li>
				</ul>
				</li>
				<li>
				<a href="https://en.wikipedia.org/wiki/Java_(programming_language)">Java</a> - an interpretive language portable across most 
				computer platforms<ul>
					<li>
					<a href="http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html">Download open source Java SE System Development Kit</a> - to 
					build JAR</li>
				</ul>
				</li>
			</ul>
			</li>
		</ul>
		</li>
		<ul>
			<ul>
				<ul>
					<li><a href="downloads">Download open source Java version of 
					IDIAC for Windows, Linux, OSX</a></li>
				</ul>
			</ul>
		</ul>
		<ul>
			<ul>
				<li><a href="https://eclipse.org/ide/">Eclipse</a> - an 
				integrated development environment for java, C++, and PHP<ul>
					<li>
					<a href="https://eclipse.org/downloads/packages/release/Neon/3">Download open source Eclipse Java IDE you can use for IDIAC</a></li>
				</ul>
				</li>
				<li><a href="https://opensource.org/">Open Source Initiative</a> 
				- initiative supporting free distribution of software </li>
			</ul>
		</ul>
	</ul>
   </td>
</tr>
</table>

<?php

  page_footer();
  
// end help.php
		

