<?php
// IDIAC Machine Language Emulator home page
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding

  session_start();              // used to save arrays across ipl, run, step
  require 'php/functions.php';  // functions for header/footer on all pages
  
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC A Simple Stored Program Computer You Can Program, Debug, and Run</title>
</head>

<?php 
  
  
  require 'php/idiac_console.php';
 
  
// end indes.php