<?php
// IDIAC Machine Language Emulator About page
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding
// 2017/04/16 dsh use rel ref from root
// 2017/05/08 dsh add open source info

    require 'php/functions.php';  
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC Machine Language Emulator About Page</title>
<style type="text/css">
.auto-style1 {
	text-align: left;
}
.auto-style2 {
	margin-left: 80px;
}
.auto-style4 {
	margin-left: 40px;
}
</style>
</head>

<?php page_header("IDIAC Stored Program Computer Emulator About Page")

  
?>

	<tr>
		<td>
		<p><strong>About IDIAC Index:</strong></p>
		<ul>
			<li><a href="#Overview"><strong>Overview</strong></a></li>
			<li><a href="#Machine_Console_Home_Page"><strong>Machine Console 
			Home Page</strong></a></li>
			<li><a href="#IDIAC_Machine_Instructions"><strong>Machine 
			Instructions</strong></a></li>
			<li><a href="#IDIAC_Machine_Language"><strong>MLC Machine Language 
			Code</strong></a></li>
			<li><a href="#IDIAC_Assembly_Language"><strong>ALC Assembly Language 
			Code</strong></a></li>
			<li><a href="#Open_Source_PHP_Version"><strong>Open Source PHP 
			Version for the web</strong></a></li>
			<li><a href="#Open_Source_Java_Version"><strong>Open Source JAVA Version for 
			Windows, Linux, and Apple OSX</strong></a></li>
			<li><a href="#History_of_IDIAC"><strong>History of IDIAC</strong></a><strong><br>
			</strong></li>
		</ul>
	
		<strong>
	
		</td>
   </tr>

   <tr><td align="left" width="800" valign="top">
	 </strong>
	 <a name="Overview"><strong>Overview</strong></a><strong><br><br>
</strong><a href="index.php"><strong>IDIAC</strong></a><strong> is a 
	web based interactive educational tool consisting of a simple 
	</strong> 
	<a href="https://en.wikipedia.org/wiki/Stored-program_computer"><strong>stored 
	program</strong></a><strong> computer emulator.&nbsp; The IDIAC computer has 10 instructions, 
	one hundred 64 bit words of 
	memory, one instruction address register, one 64 bit arithmetic register, and 
	one condition code register.&nbsp; Anyone with Internet access can learn to 
	write IDIAC programs in machine language and assembly language and then 
	interactively debug and execute them.&nbsp; <br><br>Users who find IDIAC 
	useful are encouraged to share it with other family members and friends.&nbsp; 
	IDIAC was my first introduction to stored program computers and it led to a 
	career in Information Technology including lots of programming which I still 
	love doing today.&nbsp; See the </strong> <a href="#History_of_IDIAC">
<strong>history of IDIAC</strong></a><strong>.&nbsp; 
	There is an open </strong> <a href="https://www.facebook.com/groups/IDIAC/">
<strong>IDIAC 
	Facebook group</strong></a><strong> for users to learn from each other and share information 
	including example IDIAC source programs which can be uploaded and downloaded 
	or simply opened to copy and paste source code to the IDIAC console for 
	loading and execution.&nbsp; Users are encouraged to join the group and post 
	questions and also share any example source programs they would like to 
	inclusion on the </strong> <a href="examples"><strong>IDIAC Example Program Page</strong></a>.<strong><br><br>
	The </strong> <a href="downloads"><strong>IDIAC open source tool</strong></a><strong> is 
now available in both PHP and Java.&nbsp; The
	</strong>
	<a href="http://php.net/manual/en/intro-whatis.php"><strong>PHP</strong></a><strong> 
version runs on a web server at <a href="http://www.idiac.org">www.idiac.org</a> and has been 
	tested using most browsers on PC's, tablets, and cell phones including
	</strong>
	<a href="https://www.google.com/chrome/browser/desktop/index.html">
	<strong>Chrome</strong></a><strong>, </strong> <a href="https://www.mozilla.org/en-US/firefox/">
<strong>Firefox</strong></a><strong>,
	</strong>
	<a href="https://support.microsoft.com/en-us/help/17621/internet-explorer-downloads">
	<strong>Internet Explorer</strong></a><strong>, </strong> <a href="http://www.opera.com/">
<strong>Opera</strong></a><strong>, and
	</strong>
	<a href="https://support.apple.com/en_IN/downloads/safari"><strong>Safari</strong></a><strong>.&nbsp; 
	Currently Network Solutions provides the </strong> <a href="http://www.idiac.org">
	<strong>www.idiac.org</strong></a><strong> website hosting service.&nbsp; The server running the PHP 
	IDIAC emulator code indicates that it is capable of IDIAC instruction 
	execution rate of up to about 10 million instructions per elapsed second 
	(MIPS).&nbsp; However, most of the time the server has a shared workload of 
	other websites which results in a calculated MIPS rate of about 0.3 MIPS or 
	300,000 IDIAC instructions per elapsed second.&nbsp; At the end of each 
	IDIAC execution run, the total number of instruction is divided by the 
	elapsed time to calculate an approximate MIPS rate.&nbsp; Source idiac 
programs can be copy and pasted from text file or entered directly followed by 
IPL and RUN to execute the idiac program loaded in memory by the IPL process.<br>
<br>The Java version can be downloaded as <a href="java/idiac.jar">idiac.jar</a> 
executable file and run on any platform supporting
<a href="http://www.oracle.com/technetwork/java/javase/downloads/index.html">
J2SE</a> Java.&nbsp; On an Intel i7 core processor, idiac instructions can be 
executed at over 40 MIPS.&nbsp; Both versions support copy and paste or direct 
entry of idiac source code.&nbsp; The Java version also supports reading text 
source program files from directory on the platform it is running on.&nbsp; The 
default directory can be specified as parameter to the idiac.jar file.&nbsp; <br>
<br>All the example programs have been run on both the PHP and Java versions of 
idiac. <br>
	</strong>
	<a name="Machine_Console_Home_Page"><strong><br>Machine Console Home Page</strong></a><strong><br>
	<br>The </strong> <a href="http://www.idiac.org"><strong>www.idiac.org</strong></a><strong> home page serves as 
	the console to perform initial program load (IPL), run and step commands.&nbsp; 
	Additionally the console supports copying and pasting program code to or 
	from a text area from which the IPL loads machine language or assembly 
	language code.<br>The console also displays memory contents and requested 
	instruction trace (up to last 100 instructions with default last 10 
	instructions).&nbsp; The trace entries contain the following:<br><br>
	</td>
	</tr>
	
	<tr><td colspan="3" align="left" width="800"><table align="left" width="800">
		<tr>
			<td style="width: 185px">Instruction ID</td>
			<td>Sequential ID from first instruction following last IPL</td>
		</tr>
		<tr>
			<td style="width: 185px">Instruction LOC</td>
			<td>memory location of current instruction (0 to 99)</td>
		</tr>
		<tr>
			<td style="width: 185px">Instruction memory</td>
			<td>memory location content</td>
		</tr>
		<tr>
			<td style="width: 185px">Instruction label</td>
			<td>Assigned assembly language instruction or data label if any</td>
		</tr>
		<tr>
			<td style="width: 185px">Instruction operation</td>
			<td>Operation code (L, ST, A, S, M, D, C, BP, BZ, B) or ? if 
			undefined</td>
		</tr>
		<tr>
			<td style="width: 185px">Operand label</td>
			<td>Assigned assembly language operand label if any</td>
		</tr>
		<tr>
			<td style="width: 185px">Operand address</td>
			<td>
			Operand address (0 to 99)</td>
		</tr>
		<tr>
			<td style="width: 185px">Register</td>
			<td>Register content</td>
		</tr>
		<tr>
			<td style="width: 185px">Condition Code</td>
			<td>Condition code set by A, S, M, D, or C to indicate high, 
			equal, or low</td>
		</tr>
		</table></td>
    
		
    </tr>
    
	<tr><td colspan="3" align="left" width="100%">
	</strong>
	<table align="left" width="100%">
	<tr><td align="left" width="100%">
		<b><strong>
	<br><br></strong><a name="IDIAC_Machine_Instructions"><strong>Machine Instructions</strong></a><strong><br>
	<br>Each machine instruction consists of 2 digit operation code followed by 
	2 digit memory address.&nbsp;&nbsp; The 4 arithmetic instructions plus 
	compare instruction set the condition code to indicate positive, zero, or 
	negative result.&nbsp; The load and store plus 3 branch instructions do not 
	change the condition code.&nbsp; After IPL, execution always started at 
	memory location 0. <br><br>
   	 </strong></b>
   </td>
	</tr>
	</table><strong><br></td>
	</tr>
<tr><td colspan="3" width="800">
	
	<table align="left" width="800">
	<tr>    
		<td valign="top">Opcode&nbsp;
		</td>
		<td valign="top">Mnemonic&nbsp; 
		</td>
		<td valign="top">Operation 
		</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">01</td>
		<td class="auto-style1" valign="top">L</td>
		<td class="auto-style1" valign="top">load register from memory address location</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">02</td>
		<td class="auto-style1" valign="top">ST</td>
		<td class="auto-style1" valign="top">store register at memory address location</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">03</td>
		<td class="auto-style1" valign="top">A</td>
		<td class="auto-style1" valign="top">add word at memory address 
		to register and set condition</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">04</td>
		<td class="auto-style1" valign="top">S</td>
		<td class="auto-style1" valign="top">subtract word at memory address from 
		register and set condition</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">05</td>
		<td class="auto-style1" valign="top">M</td>
		<td class="auto-style1" valign="top">Multiply register by word 
		at memory address and set condition</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">06</td>
		<td class="auto-style1" valign="top">D</td>
		<td class="auto-style1" valign="top">divide register by word at memory address 
		and set condition</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">07</td>
		<td class="auto-style1" valign="top">C</td>
		<td class="auto-style1" valign="top">compare register to word at memory address 
		and set condition</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">08</td>
		<td class="auto-style1" valign="top">BP</td>
		<td class="auto-style1" valign="top">branch if condition positive to instruction at memory address</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">09</td>
		<td class="auto-style1" valign="top">BZ</td>
		<td class="auto-style1" valign="top">branch if condition zero to instruction at memory address</td>
	</tr>
	<tr>
		<td class="auto-style1" valign="top">10</td>
		<td class="auto-style1" valign="top">B</td>
		<td class="auto-style1" valign="top">branch to instruction at memory address</td>
	</tr>
    </table><br></td>
    </tr>
	<tr><td colspan="3" width="800"><br>
	   

	<br>IDIAC execution&nbsp; will terminate for any of the following 
	conditions:
	<ul class="auto-style4">
		<li class="auto-style1">Undefined operation code (1-10)</li>
		<li class="auto-style1">Run Limit Exceeded</li>
		<li class="auto-style1">Divide by zero</li>
		<li class="auto-style1">End of memory invalid address
		</li>
		<li class="auto-style1">Any branch instruction that branches to itself</li>
		</ul>
		
	<p class="auto-style1"><br><a name="IDIAC_Machine_Language">
	Machine Language</a><br><br><strong> Machine language instruction codes can be entered directly 
	into the text area on the <a href="http://www.idiac.org">IDIAC home 
	page console</a> or the code can be copied and pasted from any of the
	<a href="examples">IDIAC Examples</a> or from any text files that 
	you can save on your computer.&nbsp; Each machine word value 
	must be separated by semicolon or line feed character (enter key).&nbsp; 
	Comment lines starting with '*' are allowed and comments can follow each 
	machine word value label 
	references and machine values with leading space.&nbsp; Here 
	is an example of IDIAC machine language code for 3 word instruction counter loop:
"302;1000;1"<br><br><a name="IDIAC_Assembly_Language">IDIAC Assembly Language</a><br>
	<br>Assembly language may be substituted for machine language by coding 
	optional instruction label, operation code mnemonic, address label, and optional 
	constants.</p>
				<p class="auto-style1">
				<table colspan="10" width="800">
					<tr>
						<td style="width: 185px">Instruction Label</td>
						<td>Optional Label starting in first position with 
						character &gt; '9'.&nbsp; Lines starting with * are ignored 
						as comments.</td>
					</tr>
					<tr>
						<td style="width: 185px">Operation mnemonic</td>
						<td>L, ST, A, S, M, D, C, BP, BZ, B or numeric value 
						for memory word</td>
					</tr>
					<tr>
						<td style="width: 185px">Operand Label</td>
						<td>Label referencing Instruction label or literal 
						starting with # followed by numeric value, preceded by 
						space</td>
					</tr>
					<tr>
						<td style="width: 185px">Comments</td>
						<td>Optional comments preceded by space, may not 
						contain double quotes</td>
					</tr>
					<tr>
						<td style="width: 185px">Delimiter</td>
						<td>Statements may be terminated by semicolon or line 
						feed (return)</td>
					</tr>
				</table>
				</p>
				<p class="auto-style1">The Initial program loader performs the 
				following steps to load assembler language:</p>
				<ol>
					<li>
					<p class="auto-style1">Load each instruction into 
					memory starting at location 0.&nbsp; Instruction labels are 
					added to defined label table with assigned memory location.&nbsp; 
					Instruction mnemonics are converted to numeric value 
					multiplied by 100 and stored in assigned memory word.&nbsp; 
					Operand labels are added to reference label table with 
					reference location. Literals are also added to the reference 
					label table.</p>
					</li>
					<li>
					<p class="auto-style1">The reference table is searched for 
					literal labels starting with #.&nbsp; Unique literals are 
					allocated to memory locations following last instruction and 
					are set to the literal value.&nbsp; Non-duplicate literal 
					labels are added to the defined label table.</p>
					</li>
					<li>
					<p class="auto-style1">Add one additional defined label 
					named "END" allocated to the next word in memory after the 
					last literal.&nbsp; This label can be referenced in any 
					IDIAC assembler program to address memory beyond the program 
					for storing data.&nbsp; See prime number and powers of 2 
					examples which use memory beyond program to build tables 
					with results which can be viewed in the memory dump after 
					execution.</p>
					</li>
					<li>
					<p class="auto-style1">The reference table is searched again 
					for each label or literal.&nbsp; For each reference, 
					the defined label table is searched for a matching label.&nbsp; 
					If found the defined label memory location is added to the 
					referenced instruction word to complete . </p>
					</li>
					<li>
					<p class="auto-style1"><br><strong> Instruction labels and 
					operand labels must match case.&nbsp; Operation mnemonics 
					can be in upper or lower case.&nbsp; Here is example of IDIAC assembler language code for 
	2 instruction counter loop:&nbsp; "LOOP A #1; B LOOP".&nbsp;&nbsp; Note the 
					assembler assigns the constant to the next location in 
					memory and sets the operand address in the add instruction.</li>
				</ol>
	</td>
		
		</tr>
		<tr>
			<td class="auto-style1">
			<a name="Open_Source_PHP_Version">Open Source PHP Version</a> for 
the Web<br>
			<br>The IDIAC open source PHP Version can be <a href="downloads">downloaded</a>, modified, and implemented on your own 
web server.&nbsp; The source module idiac/php/idiac_console.php consists of about 800 
			lines of PHP and HTML code to support the IDIAC console user interface, the IPL 
			loader, the emulator, the trace table, and memory dump.&nbsp; Some future 
			development options might include the following:<ul>
				<li>Add more instructions <li>Expand memory<li>
				Support different 
				data types such as text,&nbsp; floating point, and hex<li>
				Support input and output options<li>
				Rewrite IDIAC 800 lines of PHP in Java in order to port 
				execution to Windows, Linux, and Apple OSX (under development 
				below)</ul>
			<p><a name="Open_Source_Java_Version">Open Source Java Version</a><strong>  
			for Windows, Linux, and Apple OSX</p>
<p>As of 2017/07/30 version V1.04 of IDIAC can be
	<strong> can be <a href="downloads">downloaded</a> with a complete J2SE Java 
<a href="idiac_GUI.pdf">GUI console</a> 
interface that supports menu with File (open, save, save as, ignore changes, 
exit), Edit (cut, copy, paste, 
and select all), View (Edit view, Run view), IPL, RUN, STEP, About, and Help.&nbsp; The GUI has three scrolling 
panels: one for log of all actions, one for idiac source program,&nbsp; and one for 
display of execution instruction trace table and memory.&nbsp; The source module 
<a href="java/idiac.java">idiac.java</a> consists of about 900 lines of Java code which can be compiled and linked into executable&nbsp; 
<a href="java/idiac.jar">idiac.jar</a> file.&nbsp; Once Java SE 8.1+ has been installed, you can double click 
on the idiac.jar file to execute it and bring up idiac GUI interface.&nbsp; See 
the<a href="java/readme.txt"> idiac/java/readme.txt</a> for more information on java and eclipse IDE to use 
for java development.&nbsp; </p>
<ul>
	<li>
	Add IDIAC Java support for mobile Android devices.</li>
</ul>
			<p>Regardless of your age, if IDIAC wets your appetite to take up 
			system software development as your passion, here are some 
			additional options:</p>
			<ul class="auto-style2">
				<li>See the idiac <a href="developer_guide.php">Developer Guide 
				PDF</a></li>
				<li>Learn about the instructions for&nbsp; specific stored 
				program computers:<ol>
					<li>
					<a href="https://en.wikipedia.org/wiki/X86_instruction_listings#Original_8086.2F8088_instructions">
					Intel 
					8086 original IBM PC instruction set</a>.</li>
					<li>
					<a href="http://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-instruction-set-reference-manual-325383.pdf">
					Intel 64 and IA32 instruction set</a> for chips such as i7.</li>
					<li>
					<a href="https://developer.apple.com/library/content/documentation/DeveloperTools/Reference/Assembler/050-PowerPC_Addressing_Modes_and_Assembler_Instructions/ppc_instructions.html#//apple_ref/doc/uid/TP30000824-TPXREF101">
					PowerPC for Apple</a></li>
					<li>
					<a href="https://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=4&amp;cad=rja&amp;uact=8&amp;ved=0ahUKEwiH15n2nuDTAhWGYiYKHZdyBMoQFgg8MAM&amp;url=http%3A%2F%2Fwww.textfiles.com%2Fbitsavers%2Fpdf%2Fibm%2F370%2FprincOps%2FSA22-7085-0_370-XA_Principles_of_Operation_Mar83.pdf&amp;usg=AFQjCNGAEsfaj_b8imSIz-wHk5uMw86JIg&amp;sig2=XQczYyFZGM9SeK74nETGNg">
					IBM 370 Principles of Operation</a>.</li>
					<li>
					<a href="https://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=3&amp;cad=rja&amp;uact=8&amp;ved=0ahUKEwiU8IjhjuDTAhWEwiYKHSfLADEQFghFMAI&amp;url=http%3A%2F%2Fwww-01.ibm.com%2Fsupport%2Fdocview.wss%3Fuid%3Dpub1sa22783209&amp;usg=AFQjCNGxJGRfyReBExmqgGkXJAZUIwKm2A&amp;sig2=ZlMEpLgLn8w-MG09jTN4wA">
					IBM z/Architecture Principles of Operation</a>.</li>
				</ol>
				</li>
				<li>Learn about assemblers, linkers, and emulators for specific 
				hardware.<ul>
					<li><a href="http://www.don-higgins.net/pc370.htm">PC370</a> 
					was an IBM 370 assembler, linker, and emulator for 
				MS-DOS systems published as shareware and used at many 
					universities in the 1980's.&nbsp; </li>
					<li>
					<a href="http://publibfp.dhe.ibm.com/epubs/pdf/asmr1022.pdf">
					IBM High Level Assembler</a> (HLASM) for IBM z/OS mainframes</li>
				</ul>
				</li>
				<li>Learn about Java virtual machine for portability across 
				multiple hardware platforms<ul>
					<li>
					<a href="https://en.wikipedia.org/wiki/Java_virtual_machine">
					Java Virtual Machine for multiple platforms</a></li>
					
					<strong> 
					
					<li><a href="https://java.com/en/download/">Java</a>
						portable open source compiler and runtime downloads for 
					multiple platforms</li>
					<li>
					<a href="http://www.eclipse.org/downloads/packages/eclipse-ide-java-developers/keplersr1">Eclipse</a> portable open source development environment 
						for Java</li>
				</ul>
				
				<ul>
					<li><a href="http://www.z390.org">Z390 Portable 
				Mainframe Assembler and Emulator</a>
					is an open source 
					assembler, linker, and emulator with graphical user 
					interface&nbsp; that runs on Windows, Linux, 
				and Apple OSX.&nbsp; This tool was written entirely in open 
					source Java.</li>
				</ul>
				</ul>
		</td></tr>
		<tr><td>
			
			
			
				<a name="History_of_IDIAC">History of IDIAC</a><br><br>In 1966 Dr. R. J. Wimmert, Chairman of the 
				<a href="http://www.usf.edu/engineering/">USF College of Engineering</a> 
	Industrial Department taught a course on 
					<a href="https://en.wikipedia.org/wiki/Fortran">FORTRAN</a> programming for 
	all engineering undergraduates which included IDIAC machine language as 
	introduction to stored program computers.&nbsp; At the time USF had an
					<a href="https://en.wikipedia.org/wiki/IBM_1400_series">IBM 1410</a> 
	mainframe and FORTRAN programs had to be punched on cards and submitted for 
	overnight batch processing.&nbsp; There were no PC's, cell phones, or 
	Internet.&nbsp; Read more on the early&nbsp; 
					<a href="http://www.eng.usf.edu/pdf/envision_04_11.pdf">History of 
	USF College of Engineering</a>.&nbsp; <br><br>With the 
	launch of this <a href="http://www.idiac.org">www.idiac.org</a> 
	website anyone with Internet access can learn about how all 
				<a href="https://en.wikipedia.org/wiki/Stored-program_computer">stored program computers</a> work by coding and executing
					<a href="#IDIAC_Machine_Instructions">IDIAC Machine Language</a> programs.&nbsp; A very 
	basic<a href="#IDIAC_Assembly_Language"> 
	IDIAC Assembler Language</a> is included to aide in coding 
	more complex programs.&nbsp; The assembler language support translates 
	assembler language with alphabetic labels and operation codes into the 
	equivalent machine code.&nbsp; After coding a program with more than a few 
	instructions, the power of assembler to make programs more readable and less 
	error prone becomes clear.<br><br>If you have more questions about IDIAC, 
	please join the <a href="https://www.facebook.com/groups/IDIAC/">Facebook IDIAC Discussion Group</a> where members 
	can learn together.
	</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	
			
</strong>
	
			
<?php

  page_footer();
  
// end about.php

