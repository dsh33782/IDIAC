<?php
   $ipl_code = 
"* IDIAC Powers_of_two starting at END label generated after literals
* don@higgins.net 04/29/17 generates up to 2**31 on 64 bit integer PHP
* total instructs = 750, largest integer = 4611686018427387904
NEXT  L     NUM
             M    #2
             C     NUM
             ST   NUM
             BP   SAVE
DONE B      DONE  end if NUM * 2 not > NUM or end of memory
SAVE  ST   END      start storing powers at genderated END label after literals
             L     SAVE
             A     #1
             C     SAVE_LAST
             BP   DONE  end if out of memory
             ST   SAVE   update ST END to next memory location
              B     NEXT
SAVE_LAST ST 99 last valid ST in memory
NUM    1                     powers of 2 until overflow or out of memory";

