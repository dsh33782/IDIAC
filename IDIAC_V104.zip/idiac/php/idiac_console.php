2
<head>
<style type="text/css">
.auto-style1 {
	text-align: left;
}
.auto-style2 {
	text-align: right;
}
</style>
</head>

<?php
// IDIAC Machine Language Emulator Console Display Form
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding
// 2017/04/15 dsh comment out debugging echos 
// 2017/04/21 dsh add comment support for * and after ref labels and constants
// 2017/04/25 dsh add literal #num support - add ref label, alloc before resolving labels
// 2017/04/26 dsh add labels to trace for ins and operand
// 2017/05/29 dsh java directory and first GUI menu only version included 
//********************************************************************** 

page_header("A Simple Stored Program Computer You Can Program, Debug, and Run");

// cpu constants

   global $version;
   $version = 'V1.02';
   $op_mnemonic = array(
     'L'  => 1,
     'ST' => 2,
     'A'  => 3,
     'S'  => 4,
     'M'  => 5,
     'D'  => 6,
     'C'  => 7,
     'BP' => 8,
     'BZ' => 9,
     'B'  => 10
   );
   $op_num_mnemonic = array(
     1   => 'L',
     2   => 'ST',
     3   => 'A',
     4   => 'S',
     5   => 'M',
     6   => 'D',
     7   => 'C',
     8   => 'BP',
     9   => 'BZ',
     10  => 'B'
   );

// cpu controls

   $exec        = true; // default to only trace next instruction
   $step        = false; // execute instruction for step and run
   $repeat_step = false; // execute multiple steps for run until limit reached
 
// cpu form fields

   $ipl_code    = $_REQUEST['ipl_code'];    // MLC or ALC code to load on IPL request
   $submit_type = $_REQUEST['submit_type']; // IPL, Step, or Run
   $run_limit   = intval($_REQUEST['run_limit']);;
   $cpu_status  = $_REQUEST['cpu_status'];  // waiting, IPL, step, run, error     

   $start_time  = $_REQUEST['start_time'];
   $end_time    = $_REQUEST['end_time'];
   $start_mics  = $_REQUEST['start_mics'];
   $end_mics    = $_REQUEST['end_mics'];
 
//*****************************************************************************
// set default $ipl_code prgram if first time
//*****************************************************************************

     
   if (empty($ipl_code)){
      include 'ipl_code.php';  
   }
   // debug echo "<br>ipl_code=$ipl_code"; // debug
//*****************************************************************************
// end of default $ipl_code prgram
//*****************************************************************************
   if (empty($run_limit) or $run_limit < 1)$run_limit = 1000000;
   if ($run_limit > 1000000)$run_limit = 1000000;
   $cpu_error = false; // empty error message

// initialize memory and trace arrays.  These are saved via session at end of IPL, RUN, or STEP and restored from session before RUN or STEP

    $cpu_mem   = array_fill(0,100,0.0); // initialie 100 word memory to zeros
    $label_mem = array_fill(0,100,'');  // labels for instructions and data from ALC code if any

   // instruction trace init
   
   $trace_next      = 0;
   $trace_limit     = $_REQUEST['trace_limit'];
   if ($trace_limit < 11)$trace_limit = 11;
   if ($trace_limit > 101)$trace_limit = 101;
   $trace_ins_id    = array_fill(0,$trace_limit,0);
   $trace_ins_loc   = array_fill(0,$trace_limit,0);
   $trace_ins_mem   = array_fill(0,$trace_limit,0);
   $trace_addr_mem  = array_fill(0,$trace_limit,0);
   $trace_reg       = array_fill(0,$trace_limit,0);
   $trace_cc        = array_fill(0,$trace_limit,0);

    $start_time  = date("H:i:s");
    $start_mics = microtime(true);

// ipl - load ipl_code into memory starting at 0  

    if (empty($submit_type) or $submit_type == 'IPL'){
       $cpu_status = "IPL started";
       $cpu_error = false;
       $cpu_loc = 0;
       $cpu_reg = 0;
       $cpu_cc  = '=';
       $tot_ins = 0;
       
       // load multiple mlc or alc instructions into cpu_mem       
       
       $tot_label_def      = 0;
       $label_def_ptr      = 0;
       $code_label_def     = array_fill(0,100,'');  // instruction label
       $code_label_def_loc = array_fill(0,100,0);   // iabel address
       $tot_ins            = 0;
       $tot_label_ref      = 0;  
       $label_ref_ptr      = 0;    
       $code_label_ref     = array_fill(0,100,'');  // label ref
       $code_label_ref_loc = array_fill(0,100,0);   // label ref address
       $tot_labels   = 0;
       $tot_opcodes  = 0;
       $tot_literals = 0;
       $mem_ptr = 0;     // cpu_mem index
       $code_ptr = 0; // ipl_code text index
       // debug echo "<br>ipl_code = $ipl_code"; // debug 
       while ($mem_ptr < 100 and $code_ptr < strlen($ipl_code)){

          // skip delimiters = skip char < ' ' and ';'
          
            while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) < ' ' or substr($ipl_code,$code_ptr,1) == ';'){
               $code_ptr = $code_ptr + 1;
            }
            
          // skip entire lines starting with *
          
            while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) == '*'){
               while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= ' ' and substr($ipl_code,$code_ptr,1) != ';'){ // stop at end or cr/lf or ';'
                  $code_ptr = $code_ptr + 1;
               }
               while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) < ' ' or substr($ipl_code,$code_ptr,1) == ';'){ // stop at first char in next line
                  $code_ptr = $code_ptr + 1;
               }               
            }

 
          // get_label() - skip delimiters, if label at start of field, set mem_label and mem_label_addr
            
            // debug echo "<br>get label: mem_ptr=$mem_ptr code_ptr=$code_ptr"; // debug
            $code_start = $code_ptr;                  
            if ($code_ptr < strlen($ipl_code) and (substr($ipl_code,$code_ptr,1) > '9') and substr($ipl_code,$code_ptr,1) != ';'){  // build label def
               if ($code_ptr == $code_start){
                  
                  // set_label() - add mem_label and mem_label_addr
                  
                  $code_label_def[$tot_label_def] = substr($ipl_code,$code_ptr,1);
                  $code_label_def_loc[$tot_label_def] = $mem_ptr; // cpu_mem address of label

                  $code_ptr += 1;
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) > ' ' and substr($ipl_code,$code_ptr,1) != ';'){
                     $code_label_def[$tot_label_def] = "$code_label_def[$tot_label_def]".substr($ipl_code,$code_ptr,1);
                     $code_ptr += 1;
                     
                  }
                  $label_mem[$mem_ptr] = $code_label_def[$tot_label_def];
                  // debug echo "<br>get label at $mem_ptr $code_label_def[$tot_label_def]"; // debug
                  $tot_label_def += 1;
                  $tot_labels    += 1;

               }               
            }
           
          // get_op() - skip spaces, get op mnemonic, and set cpu_mem opcode
                
              // debug echo "<br>get op: mem_ptr=$mem_ptr code_ptr=$code_ptr"; // debug
              $cpu_mem[$mem_ptr] = 0;
              while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) == ' '){ // skip spaces
                  $code_ptr += 1;
              }
              if  ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) > '9' and substr($ipl_code,$code_ptr,1) != ';'){ // build op mnemonic
                  $code_op_mnemonic = substr($ipl_code,$code_ptr,1); 
                  $code_ptr += 1;
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) > ' ' and substr($ipl_code,$code_ptr,1) != ';' ){
                     $code_op_mnemonic = "$code_op_mnemonic".substr($ipl_code,$code_ptr,1);
                     $code_ptr += 1;
                  }
                  if (!empty($op_mnemonic[strtoupper($code_op_mnemonic)])){
                     $cpu_mem[$mem_ptr] = intval($op_mnemonic[strtoupper($code_op_mnemonic)]) * 100; // store opcode with zeros for address
                     $tot_opcodes += 1;
                  } else {
                     $cpu_error = "IPL loader undefined opcode $code_op_mnemonic at $mem_ptr";
                     $code_ptr = strlen($ipl_code); // force end
                  }
                  // debug echo "<br>set op $mem_ptr = $cpu_mem[$mem_ptr]"; // debug
              }
                          
          // get_label_ref() - skip spaces, get label ref, add code_label_ref
              
              // debug echo "<br>get label_ref: mem_ptr=$mem_ptr code_ptr=$code_ptr"; // debug

              while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) == ' '){ // skip spaces
                  $code_ptr = $code_ptr + 1;
              }
              if  ($code_ptr < strlen($ipl_code) and (substr($ipl_code,$code_ptr,1) > '9' or substr($ipl_code,$code_ptr,1) == '#') and substr($ipl_code,$code_ptr,1) != ';'){ // build label ref
                  $code_label_ref[$tot_label_ref] = substr($ipl_code,$code_ptr,1);
                  $code_label_ref_loc[$tot_label_ref] = $mem_ptr; 
                  $code_ptr = $code_ptr + 1;
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) > ' ' and substr($ipl_code,$code_ptr,1) != ';'){ // build label ref
                     $code_label_ref[$tot_label_ref] = "$code_label_ref[$tot_label_ref]".substr($ipl_code,$code_ptr,1);
                     $code_ptr += 1;
                  }
                  // debug echo "<br>get label ref at $mem_ptr $code_label_ref[$tot_label_ref]"; // debug
                  $tot_label_ref += 1;
                  
                  // skip comments after ref label
                  
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= ' ' and substr($ipl_code,$code_ptr,1) != ';'){ // stop at end or cr/lf or ';'
                     $code_ptr = $code_ptr + 1;
                  }
               }


          
          
          // get_value() - skip spaces, get signed decimal value for memory word and add to cpu_mem
         
              // debug echo "<br>get value: mem_ptr=$mem_ptr code_ptr=$code_ptr"; // debug

              while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) == ' '){
                  $code_ptr = $code_ptr + 1;
              }
              if (($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= '0' and substr($ipl_code,$code_ptr,1) <= '9') or substr($ipl_code,$code_ptr,1) == '-' or substr($ipl_code,$code_ptr,1) == '+'){
                  $code_value = substr($ipl_code,$code_ptr,1); 
                  $code_ptr = $code_ptr + 1;
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= '0' and substr($ipl_code,$code_ptr,1) <= '9'){
                     $code_value = "$code_value".substr($ipl_code,$code_ptr,1);
                     $code_ptr = $code_ptr + 1;
                  }
                  $cpu_mem[$mem_ptr] += intval($code_value); // add value to cpu_mem opcode                  
                  // debug echo "<br>add value $mem_ptr = $cpu_mem[$mem_ptr]";  // debug
                  
                  // skip comments after ref label
                  
                  while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= ' ' and substr($ipl_code,$code_ptr,1) != ';'){ // stop at end or cr/lf or ';'
                     $code_ptr = $code_ptr + 1;
                  }

              }
       
          // skip comments
          
              while ($code_ptr < strlen($ipl_code) and substr($ipl_code,$code_ptr,1) >= ' ' and substr($ipl_code,$code_ptr,1) != ';'){
                  $code_ptr = $code_ptr + 1;
              }

          $mem_ptr += 1;
       } // end parsing $ipl_code for memory load of instructions and data
       
       // allocate literals
        
       $label_ref_ptr = 0;
       while ($label_ref_ptr < $tot_label_ref and empty($cpu_error)){
          $label_def_ptr = 0;
          $literal_found = false;
          while ($label_def_ptr < $tot_label_def and empty($cpu_error)){
             if ($code_label_ref[$label_ref_ptr] == $code_label_def[$label_def_ptr]){
                $literal_found = true; // allready allocated so ignore                  
                // debug echo "<br>add label location $code_label_def_loc[$label_def_ptr] to reference location $code_label_ref_loc[$label_ref_ptr] "; // debug
                $label_def_ptr = $tot_label_def; // force end of def search
             } else {
                // debug echo "<br>ref literal $code_label_ref[$label_ref_ptr] not = def label $code_label_def[$label_def_ptr]"; // debug
             }
             // debug echo "<br>ref ptr=$label_ref_ptr def ptr=$label_def_ptr error=$cpu_error"; // debug  
             $label_def_ptr += 1; // search for next ref literal            
          }
          if (!$label_found and substr($code_label_ref[$label_ref_ptr],0,1) == '#'){
             $cpu_mem[$mem_ptr] = intval(substr($code_label_ref[$label_ref_ptr],1)); // add constant lit to end of program in memory
             $label_mem[$mem_ptr] = $code_label_ref[$label_ref_ptr];
             // debug echo "<br>alloc literal at $mem_ptr = $cpu_mem[$mem_ptr]"; // debug
             $code_label_def[$tot_label_def] = $code_label_ref[$label_ref_ptr]; 
             $code_label_def_loc[$tot_label_def] = $mem_ptr; 
             $mem_ptr += 1; 
             $tot_label_def += 1; // add literal definition
             $tot_literals  += 1; // count literals
       
          }
          $label_ref_ptr += 1;
       }  // end processing label references
       
       // add END label to refenece first location past literals
       
       $code_label_def[$tot_label_def] = 'END'; 
       $code_label_def_loc[$tot_label_def] = $mem_ptr;
       $label_mem[$mem_ptr] = 'END'; 
       $tot_label_def += 1; // add literal definition
       


       
       // lookup label refs and add label loc to cpu_mem opcode
       
       // debug echo "<br>lookup label refs and add location of target label to ref location"l // debug
       $label_ref_ptr = 0;
       while ($label_ref_ptr < $tot_label_ref and empty($cpu_error)){
          $label_def_ptr = 0;
          $label_found = false;
          while ($label_def_ptr < $tot_label_def and empty($cpu_error)){
             if ($code_label_ref[$label_ref_ptr] == $code_label_def[$label_def_ptr]){
                $label_found = true;
                $cpu_mem[$code_label_ref_loc[$label_ref_ptr]] = intval($cpu_mem[$code_label_ref_loc[$label_ref_ptr]]) + intval($code_label_def_loc[$label_def_ptr]);                  
                // debug echo "<br>add label location $code_label_def_loc[$label_def_ptr] to reference location $code_label_ref_loc[$label_ref_ptr] "; // debug
                $label_def_ptr = $tot_label_def; // force end of def search
             } else {
                // debug echo "<br>ref label $code_label_ref[$label_ref_ptr] not = def label $code_label_def[$label_def_ptr]"; // debug
             }
             // debug echo "<br>ref ptr=$label_ref_ptr def ptr=$label_def_ptr error=$cpu_error"; // debug  
             $label_def_ptr += 1;             
          }
          if (!$label_found){
             $cpu_error = "IPL loader undefined label $code_label_ref[$label_ref_ptr] at $code_label_ref_loc[$label_ref_ptr]";
          }
          $label_ref_ptr += 1;
       }  // end processing label references
      
       // save cpu and trace info after IPL load.  See session_start() in index.php before header etc.
       
       $_SESSION['cpu_mem']   = $cpu_mem;
       $_SESSION['label_mem'] = $label_mem;   
       
       $_SESSION['tot_ins']        = $tot_ins;
       $_SESSION['cpu_loc']        = $cpu_loc;
       $_SESSION['trace_next']     = $trace_next;
       $_SESSION['trace_ins_id']   = $trace_ins_id;
       $_SESSION['trace_ins_loc']  = $trace_ins_loc;
       $_SESSION['trace_ins_mem']  = $trace_ins_mem;
       $_SESSION['trace_addr_mem'] = $trace_addr_mem;
       $_SESSION['trace_reg']      = $trace_reg;
       $_SESSION['trace_cc']       = $trace_cc;

       $cpu_status = "IPL Completed loading memory Words: $mem_ptr Labels: $tot_labels  Opcodes: $tot_opcodes  Literals: $tot_literals - waiting"; 
    
// step - execute next instruction

    } else if ($submit_type == 'STEP'){
       // debug echo "Step ended started at LOC=$cpu_loc MEM=$cpu_mem[$cpu_loc]"; // debug
       $cpu_status  = "Step completed next instruction - waiting";
       $step        = true; 
       $repeat_step = true;
       $exec_limit  = 1;
       

    
// start - execute instructions until exception occurs

    } else if ($submit_type == 'RUN'){
       // debug echo "<br>Run started at LOC=$cpu_loc MEM=$cpu_mem[$cpu_loc]"; // debug
       $step          = true;
       $repeat_step   = true;
       $exec_limit    = $run_limit;
             
    }

// execute instructions for step or run
   
   if ($step){
   
        // restore cpu_mem and label_mem from session
       
       $cpu_mem = $_SESSION['cpu_mem'];
       $label_mem = $_SESSION['label_mem'];
 
       // restore trace info from session

       $tot_ins        = $_SESSION['tot_ins'];
       $cpu_loc        = $_SESSION['cpu_loc'];
       $cpu_reg        = $_SESSION['cpu_reg'];
       $cpu_cc         = $_SESSION['cpu_cc'];
       
       $trace_next     = $_SESSION['trace_next'];
       $trace_ins_id   = $_SESSION['trace_ins_id'];
       $trace_ins_loc  = $_SESSION['trace_ins_loc'];
       $trace_ins_mem  = $_SESSION['trace_ins_mem'];
       $trace_addr_mem = $_SESSION['trace_addr_mem'];
       $trace_reg      = $_SESSION['trace_reg'];
       $trace_cc       = $_SESSION['trace_cc'];

   }
   
   
   $exec    = true; // save trace info and then execute step if step or run, repeat while (exec, step, and repeat step)
   $run_ins = 0;    // count instructions in run unit up to run_limit
   while ($exec){
      $ins_opcode = intval($cpu_mem[$cpu_loc]/100);
      $ins_addr   = intval($cpu_mem[$cpu_loc])-intval($ins_opcode * 100);
      $trace_ins_id[$trace_next]   =$tot_ins+1;
      $trace_ins_loc[$trace_next]  =$cpu_loc;
      $trace_ins_mem[$trace_next]  =$cpu_mem[$cpu_loc];
      $trace_addr_mem[$trace_next] =$cpu_mem[$ins_addr];
      $trace_reg[$trace_next]      =$cpu_reg;
      $trace_cc[$trace_next]       =$cpu_cc;
      
      // debug echo "<br>trace before loc=$cpu_loc ins=$cpu_mem[$cpu_loc] op=$opcode addr=$ins_addr addr_mem=$cpu_mem[$ins_addr]"; // debug
    
   
         
     if ($step){ // execute next instruction if step or run
    
      switch ($ins_opcode) {
        case 1: // L - load 
          $cpu_reg = intval($cpu_mem[$ins_addr]);          
          $cpu_loc += 1;          
        break;
        case 2: // ST - store
          $cpu_mem[$ins_addr] = $cpu_reg;
          $cpu_loc += 1;
        break;        
        case 3: // A - add 
          $cpu_reg = $cpu_reg + intval($cpu_mem[$ins_addr]);          
          if ($cpu_reg > 0){
             $cpu_cc = '>';
          } else if ($cpu_reg < 0){
             $cpu_cc = '<';
          } else {
             $cpu_cc = '=';
          }  
          $cpu_loc += 1;          
        break;
        case 4: // S - subtract 
          $cpu_reg =  $cpu_reg - intval($cpu_mem[$ins_addr]);
          if ($cpu_reg > 0){
             $cpu_cc = '>';
          } else if ($cpu_reg < 0){
             $cpu_cc = '<';
          } else {
             $cpu_cc = '=';
          } 
          $cpu_loc += 1;
        break;
        case 5: // M - multiply 
          $cpu_reg = intval($cpu_reg * $cpu_mem[$ins_addr]);
          if ($cpu_reg > 0){
             $cpu_cc = '>';
          } else if ($cpu_reg < 0){
             $cpu_cc = '<';
          } else {
             $cpu_cc = '=';
          } 
          $cpu_loc += 1;
        break;
        case 6: // D - divide          
          if ($cpu_mem[$ins_addr] != 0){
             $cpu_reg =  intval($cpu_reg / $cpu_mem[$ins_addr]);
             
             if ($cpu_reg > 0){
                $cpu_cc = '>';
             } else if ($cpu_reg < 0){
                $cpu_cc = '<';
             } else {
               $cpu_cc = '=';
             }          
             $cpu_loc += 1;
          } else {
             $cpu_error = "divide by zero error - waiting";
          }          
        break;
        case 7: // C - compare 
          if ($cpu_reg > intval($cpu_mem[$ins_addr])){
             $cpu_cc = '>';
          } else if ($cpu_reg < intval($cpu_mem[$ins_addr])){
             $cpu_cc = '<';
          } else {
             $cpu_cc = '=';
          }
          $cpu_loc += 1;          
        break;
        case 8: // BP - branch positive to addr
          if ($cpu_cc == '>'){
             if ($ins_addr == $cpu_loc){
                $cpu_error = "BP to self loop stopped - waiting";
             }
             $cpu_loc = $ins_addr;
          } else {          
             $cpu_loc += 1;
          }         
        break;        
        case 9: // BZ - branch zero to addradd 
          if ($cpu_cc == '='){
             if ($ins_addr == $cpu_loc){
                $cpu_error = "BZ to self loop stopped - waiting for IPL";
             }
             $cpu_loc = $ins_addr;
          } else {          
             $cpu_loc += 1;             
          }            
        break;
        case 10: // B - branch to addr
          if ($ins_addr == $cpu_loc){
             $cpu_error = "B to self loop stopped - waiting for IPL";
          }  
          $cpu_loc =  $ins_addr;
        break;
        default:
          $cpu_error = "Invalid opcode - waiting for IPL";
      }
      if (empty($cpu_error)){
         $run_ins += 1;
         $tot_ins += 1;     
         if ($cpu_loc >= 100){
            $cpu_error = "Invalid ins loc $cpu_loc - waiting";
            $step = false;
         }
      } else {
         $step = false;
      }
     } // end if step
     
     if (!$repeat_step or !empty($cpu_error)){
        $exec = false;
     } else {
        $trace_next += 1;
        if ($trace_next >= $trace_limit)$trace_next = 0;
        if ($run_ins >= $exec_limit){
           $repeat_step = false;
           $step        = false;
        }
     } 
   }  // end while exec
   
   // update session mem info after execution (note label_mem only updated by IPL
 
   $_SESSION['cpu_mem']   = $cpu_mem;
       
   // update session trace info aftersave tracerestore trace info from session

   $_SESSION['tot_ins']        = $tot_ins;
   $_SESSION['cpu_loc']        = $cpu_loc;
   $_SESSION['cpu_reg']        = $cpu_reg;
   $_SESSION['cpu_cc']         = $cpu_cc;
   $_SESSION['trace_next']     = $trace_next;
   
   $_SESSION['trace_ins_id']   = $trace_ins_id;
   $_SESSION['trace_ins_loc']  = $trace_ins_loc;
   $_SESSION['trace_ins_mem']  = $trace_ins_mem;
   $_SESSION['trace_addr_mem'] = $trace_addr_mem;
   $_SESSION['trace_reg']      = $trace_reg;
   $_SESSION['trace_cc']       = $trace_cc;

   
   $end_time = date("H:i:s");
   $end_mics = microtime(true);
   $mics = $end_mics - $start_mics;
   if ($mics > 0){
      $tot_sec = $mics;
      $mips    = $run_ins/($mics*1000000);
   }
   // debug echo "<br>cpu_error=$cpu_error cpu_status=$cpu_status"; // debug
   if (!empty($cpu_error)){
      $cpu_status = $cpu_error;
   } else if ($submit_type == 'RUN'){
      $cpu_status    = "Run executed next $run_ins instructions - waiting";
   }
   
   ?> 

        <form name="idiac_console_form" method="get">
		 <table width="100%">
			<tr>
				<td align="left" style="width: 328" valign="top"><strong>&nbsp;<textarea name="ipl_code" id="ipl_code_id" rows="5" style="width: 317px"
				 title="Copy and paste or enter IDIAC machine language or assembly language code"><?php echo $ipl_code?></textarea></strong></td>
				<td class="auto-style1" valign="top"><strong>
				Select and then paste
				<a href="../examples/index.php">example</a> 
				or enter your own program<br>Click IPL 
				button for Initial Program Load into memory<br>Click RUN button 
				to execute instructions up to run limit<br>Click STEP button to execute next 
				instruction<br>
				Select, copy,
						
						and then paste to text file to save program</strong></td>
		    </tr>
		    <tr>
		        <td colspan="3" class="auto-style1" valign="top">
						<strong> 
						<input name="submit_type" type="submit" value="IPL"
						 title="Initial Program Load of IDIAC code into memory"" />
						&nbsp;<input name="submit_type" type="submit" value="RUN"
						 title="Execute IDIAC program starting at location 0 and display instruction trace and memory" />
						&nbsp;<input name="submit_type" type="submit" value="STEP" 
						 title="Execute next instruction and display instruction trace and memory"/> 
						Run Limit: 
						<input name="run_limit" type="text" value="<?php echo $run_limit;?>" style="width: 68px"
						 title="Enter maximum number of instructions to execute" />&nbsp;
						Trace Limit: 
						<input name="trace_limit" type="text" value="<?php echo $trace_limit;?>" style="width: 68px"
						 title="Enter maximum number of instructions to trace" /> 
						See trace for register and instructions&nbsp; 
												
						</strong></td>
					</tr>
		        <table width=800>
		        <tr>
			          <td colspan="5"><strong><?php echo $cpu_status;?></strong></td>
			         
			     </tr>

		        	
                <?php if ($run_ins >= 100){ ?>
			        <tr>
				     <?php
				       $tot_sec2d = sprintf('%0.2f', $tot_sec);
				       $mips2d    = sprintf('%0.2f', $mips);
				     ?>

			         <td style="width: 354px" class="auto-style1" valign="top"><strong>Run Timing for last <?php echo $run_ins?> instructions</strong></td>
			         <td class="auto-style1" style="width: 114px" valign="top">
				     <strong>Start: <?php echo $start_time;?></strong></td>
			         <td class="auto-style1" valign="top" style="width: 134px">
				     <strong>End: <?php echo $end_time;?></strong></td>
				     <td class="auto-style1" valign="top" style="width: 129px">
				     <strong>Seconds: <?php echo $tot_sec2d?></strong></td>
				     <td class="auto-style1" valign="top" style="width: 113px">
				     <strong>MIPS: <?php echo $mips2d?></strong></td>
				  </tr>
				  
              <?php } // end of skip timing
                  ?>
              					

				</table>				
		    </table>
		    </form>
<?php

// trace up to 10 instructions and next instruction to be executed

         ?>
             <tr><td>
             <table align="left" style="width: 100%">
               <tr><td colspan="11"><strong>Trace of last <?php $trace_limit1 = $trace_limit-1;echo $trace_limit1?> instructions plus next instruction</strong></td>
              </tr>
              <tr>
                  <td class="auto-style2" valign="top" style="width: 41px"><strong>ID</strong></td>
                  <td class="auto-style2" valign="top"><strong>Loc</strong></td>
			      <td class="auto-style2" style="width: 69px" valign="top">
				  <strong>Memory</strong></td>
			      <td class="auto-style1" style="width: 86px" valign="top">
				  <strong>Ins-Label</strong></td>
			      <td class="auto-style1" valign="top"><strong>Op</strong></td>
			      <td class="auto-style1" style="width: 109px" valign="top">
				  <strong>Addr-Label</strong></td>
			      <td class="auto-style2" style="width: 30px" valign="top">
				  <strong>Addr</strong></td>
			      <td class="auto-style2" style="width: 67px" valign="top">
				  <strong>Memory</strong></td>
			      <td class="auto-style2" style="width: 79px" valign="top">
				  <strong>Register</strong></td>
			      <td class="auto-style1" style="width: 39px" valign="top">
				  <strong>Condition</strong></td>
			      <td class="auto-style2" valign="top"><strong></strong></td>
              </tr>

         
         <?php
         $trace_done = false;
         $trace_cur = $trace_next + 1;
         if ($trace_cur >= $trace_limit)$trace_cur = 0; 
         while(!$trace_done){
            // debug echo "<br>trace_cur=$trace_cur trace_ins_id=$trace_ins_id[$trace_cur]"; // debug    
            if ($trace_ins_id[$trace_cur] > 0){ 
               $ins_opcode = intval($trace_ins_mem[$trace_cur]/100);
               $ins_addr   = intval($trace_ins_mem[$trace_cur])-intval($ins_opcode * 100);
               $ins_op     = $op_num_mnemonic[$ins_opcode];
               if (empty($ins_op))$ins_op = '?';
               ?>
               <tr><td align=right style="width: 41px"><strong><?php echo $trace_ins_id[$trace_cur]?>
				   </strong></td>
                   <td align=right style="width: 40px"><strong><?php echo $trace_ins_loc[$trace_cur]?>
				   </strong></td>
                   <td align=right style="width: 69px"><strong><?php echo $trace_ins_mem[$trace_cur]?>
				   </strong></td>
                   <td align="left" valign="top" style="width: 86px"><strong><?php echo $label_mem[$trace_ins_loc[$trace_cur]]?>
				   </strong></td>
                   <td align=left style="width: 23px"><strong><?php echo $ins_op?>
				   </strong></td>
                   <td align="left" valign="top" style="width: 109px"><strong><?php echo $label_mem[$ins_addr]?>
				   </strong></td>
                   <td align=right style="width: 30px"><strong><?php echo $ins_addr?>
				   </strong></td>
                   <td align=right style="width: 67px"><strong><?php echo $trace_addr_mem[$trace_cur]?>
				   </strong></td>
                   <td align=right style="width: 79px"><strong><?php echo $trace_reg[$trace_cur]?>
				   </strong></td>
                   <td style="width: 39px" class="auto-style1"><strong><?php echo $trace_cc[$trace_cur]?>
				   </strong></td>
                </tr>
               <?php
               if ($trace_cur == $trace_next)$trace_done = true;
            }
            $trace_cur += 1;
            if ($trace_cur >= $trace_limit)$trace_cur = 0;            
         }
         ?>
         </table><br></td></tr>
        

<?php
// idiac memory dump

 ?>
 <tr><td>
      <table align=left width=800>
         <tr><td colspan="10"><strong>Memory Dump</strong></td></tr>
     <?php
     $row = 0;
     while ($row < 10){ // display 10 rows of 10 memory words in decimal
       ?>
       <tr>
       <?php
       $mem_ptr = $row;
       while ($mem_ptr < 100){
          ?>
          <td><strong><?php echo "$mem_ptr:$cpu_mem[$mem_ptr]"?></strong></td>
          <?php
          $mem_ptr = $mem_ptr + 10;
       }
    ?>
    </tr>
    <?php
    $row = $row + 1;
 }
 ?>
 </table><br></td></tr>
 
<?php

 page_footer();

// end idiac_console
