

<?php
// IDIAC shared functions
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding
// 2017/04/16 dsh use rel ref from root
function page_header($text){
 ?>
 <table width="800">
 <tr><td>
   <table align="left">
	 <tr>
		<td class="auto-style1" valign="top">
		        <strong>
		        <img src="http://www.idiac.org/images/idiac.jpg" align="top">   
		        <?php echo $text;?>
			    </strong>				
		</td>
     </tr>
 	 <tr>
		<td class="auto-style1" valign="top">
		        <strong>
		        <a href="http://www.idiac.org"           ><input type="button" value="Home" /></a>
		        <a href="http://www.idiac.org/about.php" ><input type="button" value="About" /></a>		        
		        <a href="http://www.idiac.org/examples"  ><input type="button" value="Examples" style="width: 89px" /></a>
		        <a href="https://groups.yahoo.com/neo/groups/IDIAC/info">
				<input type="button" value="Email Group" style="width: 103px" /></a>
				<a href="https://www.facebook.com/groups/IDIAC/"><input type="button" value="Facebook Group" style="width: 137px" /></a>
				<a href="https://www.facebook.com/IDIAC.CPU/"><input type="button" value="Facebook Page" style="width: 123px" /></a>
		        <a href="http://www.idiac.org/help.php " ><input type="button" value="Help" /></a>
			    </strong>				
		</td>
     </tr>   
    </table></td>
  </tr>
   
<?php
}

function page_footer(){
 global $version;
 ?>
   <tr><td>
      <table align="left" width=800>
	  <tr>
		 <td>   
		        <strong>Copyright 2017 
				<a href="mailto:don@higgins.net?subject=Contact IDIAC Webmaster">Don Higgins</a> under open source general public license
				<br>Version <?php echo $version?>
				&nbsp;<a href="http://www.IDIAC.org/downloads">Open Source Downloads</a>
				</strong>
				
   		</td>
    </tr>
    </table></td>
 </tr>
<?php
}

function show_code($source_title,$source_code) {
  ?>
  <head>
  <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
  <title><?php echo $source_title?></title>
  </head>
  <?php>
  page_header($source_title);
  ?>
  <form>
  <tr><td>
      <table style="width: 800" cellpadding="0">
      <tr><td>Select all, copy to clipboard, return to home page, select all, paste code, then IPL 
		  and RUN.
	  <br></td></tr>
          <tr><td class="auto-style4">
        <strong>
		<textarea name="ipl_code" id="ipl_code_id" rows="20" class="auto-style3" style="width: 725px"><?php echo $source_code?></textarea></strong>
      </td></tr>
  </table>
  </form>
  <?php
  page_footer();
}

// end functions.php