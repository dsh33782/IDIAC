<?php
// IDIAC Machine Language Emulator Development Guide page
// copyright 2017 Don Higgins under open source general public license
// 2017/07/26 dsh initial coding

    require 'php/functions.php';  
?>
<head>
<meta content="en-us" http-equiv="Content-Language">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC Machine Language Emulator Developer Guide Page</title>
</head>

<?php page_header("IDIAC Stored Program Computer Emulator Developer Guide Page")

?>
<tr><td>
<p><strong>The IDIAC stored program computer emulator currently has 2 versions.&nbsp; 
The first version is written in 
<a href="https://en.wikipedia.org/wiki/PHP">PHP</a> which runs on web server and can be invoked from </strong>
<a href="http://www.idiac.org"><strong>www.idiac.org</strong></a><strong> using any web browser,&nbsp; 
The second is written in 
<a href="http://www.oracle.com/technetwork/java/javase/downloads/index.html">J2SE</a> Java compiled to </strong>
<a href="java/idiac.jar"><strong>idiac.jar</strong></a><strong> file which uses Swing GUI user 
interface and runs on any platform with current J2SE runtime installed.&nbsp; 
Both versions are open source and can be downloaded from the </strong>
<a href="downloads/index.php"><strong>www.idiac.org/downloads</strong></a><strong> directory.&nbsp; 
This document is a living document intended to help those PHP and Java 
developers interested in learning the languages and implementing extensions or 
other applications.</strong></p>
<p><strong>See reference links on </strong> <a href="help.php">
<strong>www.idiac.org/help</strong></a><strong> 
page for downloads recommended for development using PHP or Java.</strong></p>
<p><strong>Here is indented list of all the classes and procedures in the
<a href="java/idiac.java">idiac.java</a> source code totaling about 900 lines of 
code:</strong></p>
<ul>
	<li><strong>Public class idiac extends JPanel defines idiac as a J2SE Java 
	Swing GUI application starting with global shared variables across all 
	procedures</strong><ul>
		<li><strong>Public idiac defines callable idiac program that can be packaged as executable idiac.jar file (see 
		sample <a href="idiac_GUI.pdf">GUI screen in PDF</a>)</strong><ul>
			<li><strong>Defines frame with menu bar and 3 resizable text areas (log for 
			all actions, pgm for source program text, and display for 
			instruction trace and memory dump)</strong></li>
			<li><strong>Class MenuActionListener defines menu actions and 
			tooltips for (file, edit, view, IPL, Run, Step, About, and Help)</strong></li>
			<li><strong>Class RunLimitActionListener defines action for input 
			field with maximum instructions per run unit</strong></li>
			<li><strong>Class TraceLimitActionListener defines action for input 
			field with maximum instructions to trace</strong></li>
			<li><strong>Create and add&nbsp; menu bar to frame</strong></li>
			<li><strong>Add 3 text area panels to frame </strong></li>
			<li><strong>Public edit_view and run_view to change text area sizes</strong></li>
			<li><strong>Public open_web to open about or help pages</strong></li>
			<li><strong>Public next_char to parse source code characters</strong></li>
			<li><strong>Public update_trace_entry, right_justify, and 
			left_justify, display_trace_and_memory formatting routines </strong></li>
			<li><strong>Public idiacIPL (about 100 lines) parses source program and loads it into 
			memory along with literals, and memory labels</strong></li>
			<li><strong>Public idiacRUN (about 250 lines) executes IDIAC instructions up to 
			run_limit and traces last trace_limit instructions</strong></li>
			<li><strong>Private createAndShowGUI and Public run</strong></li>
		</ul>
		</li>
	</ul>
	</li>
</ul>

<p><strong>Much of the procedural code for IPL parsing and RUN execution was 
lifted directly from the idiac PHP code to the Java code.&nbsp; The first changes were to drop 
all the $ prefixes from names and replace PHP functions with Java functions.&nbsp; 
The more challenging change was to deal with differences in handling if and 
while expressions.&nbsp; PHP would skip other terms if first term in an AND 
expression was false whereas Java would not causing exceptions if other terms 
were not valid.&nbsp; This required recoding and using new function 
next_char(type,char) to parse the source code during IPL.&nbsp; Eclipse is a 
great tool for debugging new Java code as it will detect syntax and function 
data type errors.&nbsp; For those new to Java, you can use Google search on any 
java function you want to do and you will find lots of references.</strong></p>
<p><strong>There are no security restrictions included except that the save and 
save as actions will always check for file suffix of .txt and add it if not 
found.&nbsp; Any restrictions on file directory access are left to the host 
system.&nbsp;&nbsp; The idiac.jar executable can be used as a monospaced text 
editor in addition to using the idiac functions. </strong></p>
<p><strong>The Java version will execute idiac code at over 40 MIPS on an i7 
Intel core processor.&nbsp; The PHP version running on shared web server will 
sometimes run up to 10 MIPS and sometimes under 1 MIP depending on network 
traffic sharing processor time on the server.</strong></p>
<p><strong>When time permits, I map go back and update the PHP version to use 
the same menu bar and text areas as the Java version.&nbsp; Of course some users 
may choose to create new versions of idiac with more instructions and more 
memory in order to perform different tasks.&nbsp; However, in honor of Dr. 
Wimmert at USF, it is my plan to keep the </strong>
<a href="http://www.idiac.org"><strong>www.idiac.org</strong></a><strong> 
version limited to 10 different instructions and 100 words of memory.&nbsp; I 
hope many will find this educational tool useful in teaching others about what 
assembly language programming is about and how all computers work at a 
conceptual level.</strong></p>
</td></tr>
<?php

  page_footer();
  
// end about.php



