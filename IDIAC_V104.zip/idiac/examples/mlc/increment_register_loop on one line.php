<?php>
require '../../php/functions.php';
show_code("IDIAC MLC program to increment register and loop on one line","
* This examle IDIAC MLC program increments register and loops until run limit reached
* alternatively you can use simicolons to enter the 3 machine codes on one line
302;1000;1
");
// end of show_code php 