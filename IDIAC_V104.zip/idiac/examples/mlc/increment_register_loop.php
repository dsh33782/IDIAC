<?php>
require '../../php/functions.php';
show_code("IDIAC MLC program to increment register and loop","
* This examle IDIAC MLC program increments register and loops until run limit reached
* alternatively you can use simicolons to enter the 3 machine codes on one line
302 loop  a #1    add one to register
1000      b loop  branch back to repeat add
1         constant 1 referenced by add
");
// end of show_code php 