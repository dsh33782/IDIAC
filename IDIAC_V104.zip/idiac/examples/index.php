<?php
// IDIAC Machine Language Emulator Help page
// copyright 2017 Don Higgins under open source general public license
// 2017/04/10 dsh initial coding
// 2017/04/16 dsh use rel ref from root

//**********************************************************************
  require '../php/functions.php';
  
?>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>IDIAC Machine Language Emulator Help Page</title>
</head>

<?php page_header("IDIAC Example Programs")

?>

<table align="left" width="800">
<tr><td>
	<ul>
		<li>IDIAC <a href="../about.php#IDIAC_Machine_Instructions">MLC</a> Machine 
		Language Code Examples<ul>
			<li><a href="mlc/increment_register_loop.php">increment 
			register loop</a></li>
			<li><a href="mlc/increment_register_loop%20on%20one%20line.php">
			increment register loop on one line</a></li>
		</ul>
		</li>
		<li>IDIAC <a href="../about.php#IDIAC_Assembly_Language">ALC </a>Assembly 
		Language Code Examples<ul>
			<li>I<a href="alc/increment_register_loop.php">ncrement 
			register loop</a></li>
			<li><a href="alc/powers_of_two.php">Powers of two (Default 
			program)</a></li>
			<li><a href="alc/prime_number_sieve.php">Prime number sieve</a></li>
			<li><a href="alc/perfect_numbers.php">Perfect numbers</a></li>
			<li><a href="alc/pi.php">Pi up to 3.14159</a> </li>
			<li>Square root of 2 (coming next)</li>
			<li>Ackerman Function</li>
		</ul>
		</li>
		<li>IDIAC Test Programs<ul>
			<li><a href="tests/test_branch_positive_to_self_error.php">test BP 
			loop to self error</a></li>
			<li><a href="tests/test_branch_zero_to_self_error.php">test BZ loop 
			to self error</a></li>
			<li><a href="tests/test_branch_to_self_error.php">test B&nbsp;&nbsp; 
			loop to self error</a></li>
			<li><a href="tests/test_constants.php">test constants</a></li>
			<li><a href="tests/test_divide_by_zero_error.php">test divide by 
			zero error</a></li>
			<li><a href="mlc/test_end_of_memory_error.php">test end 
			of memory</a></li>
			<li><a href="tests/test_instructions.php">test instructions</a></li>
		</ul>
		</li>
		<ul>
			<li><a href="tests/test_branch_positive_to_self_error.php">t</a><a href="tests/test_undefined_opcode_error.php">test undefined 
			opcode_error</a></li>
			<li><a href="tests/test_undefined_label_error.php">test undefined 
			label error</a></li>
		</ul>
	</ul>
   </td>
</tr>
</table>

<?php

  page_footer();
  
// end help.php
		

