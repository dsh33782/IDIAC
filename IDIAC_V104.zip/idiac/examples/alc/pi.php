<?php>
require '../../php/functions.php';
show_code("IDIAC ALC Calculate Pi up to 3.14159","
* Calculate Pi using  accelerated version of Leibniz series  pi = 4 - 4/3 + 4/5 - 4/7 + 4/9
*  pi = 8/((4n+1)*(4n+3)) for n=0 to i = 8/(1*3) + 8/(5*7) + 8/(9*11) etc
* 3.1415926535897932384626433832795028841971693993751...
* 3.14159 after 9899506 instructions when TERM goes to 0
* execution required 0.147 seconds at 67 MIPS on Dell i7 processor
* https://en.wikipedia.org/wiki/Leibniz_formula_for_%CF%80#Convergence
* http://mathworld.wolfram.com/PiFormulas.html
* don@higgins.net 07/26/17
NEXT   L    DIV1
   A    TWO
   M    DIV1
   ST  DIVISOR
   L     EIGHT
   D    DIVISOR
   ST  TERM
   BZ  DONE
   A       PI
   ST     PI
   L     DIV1
   A     FOUR
   ST   DIV1
   B     NEXT
DONE   L   PI
LOOP   BZ  LOOP
TWO    2
FOUR 4
PI         0
EIGHT     8000000000000
DIV1         1
DIVISOR 0
TERM       0
");
// end of show_code php