<?php>
require '../../php/functions.php';
show_code("IDIAC ALC Perfect Numbers","
* perfect numbers - sum of all divisors equals number such as 1+2+3 = 6
*   Using Euclid formula sum(1+doubles up to prime)*last double = perfect #   https://www.britannica.com/topic/perfect-number
*   Perfect numbers beyond 6 = 28, 496, 8128, and 33550336 found within first 1 million instructions in under 2 seconds 
* 2017/05/09 don@higgins.net
NEXT_PRIME  L   PRIME
  A   #2
  ST  PRIME  NEXT ODD NUMBER TO TEST
  L    #3
  ST DIVISOR 
NEXT_DIVISOR  L   PRIME 
  D   DIVISOR
  ST QUOTIENT
  M   DIVISOR
  C    PRIME
  BZ NEXT_PRIME
  L  DIVISOR
  C  QUOTIENT
  L   PRIME
  BP TEST_PERFECT
  L    DIVISOR
  A    #2
  ST  DIVISOR
  B   NEXT_DIVISOR
* TEST IF SUM = 1+SUM(DOUBLES) = PRIME
TEST_PERFECT  L SUM
COMPARE_SUM   C  PRIME
    BP  NEXT_PRIME
    BZ PERFECT_CALC
    L    DOUBLES
    M   #2
    ST DOUBLES
    A   SUM
    ST SUM
    B COMPARE_SUM
PERFECT_CALC  M DOUBLES
STORE_PERFECT ST END  STARTING AT END
    ST LAST_PERFECT
    L  STORE_PERFECT
    A  #1
    ST STORE_PERFECT
    C    STORE_PERFECT_LAST
    BP  MEMORY_FULL
    L   LAST_PERFECT
    C   MAX_PERFECT
    BP  DONE
    B   NEXT_PRIME
DONE B DONE
MAX_PERFECT  10000000
LAST_PERFECT 0
STORE_PERFECT_LAST ST 99
MEMORY_FULL B  MEMORY_FULL
* VARIABLES
PRIME         3
DIVISOR     0
QUOTIENT 0
DOUBLES  2
SUM             3    SUM OF 1+DOUBLES UP  TO NEXT MATCHING PRIME
* LITERALS ADDED HERE FOLLOWED BY END LABEL
");
// end of show_code php
