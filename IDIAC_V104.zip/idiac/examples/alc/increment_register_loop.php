<?php>
require '../../php/functions.php';
show_code("IDIAC ALC program to increment register and loop","
* This examle IDIAC ALC program increments register and loops until run limit reached
loop  a #1    add one to register
      b loop  branch back to repeat add 1
");
// end of show_code php 